import pygame
import random
import sys
import os

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
BIRD_SIZE = 30
PIPE_WIDTH = 100
PIPE_GAP = 100  # Base gap size, will be modified per pipe
PIPE_SPEED = 3
GRAVITY = 0.5
JUMP_STRENGTH = -8
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 128, 0)
BLUE = (135, 206, 235)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)

class Bird:
    def __init__(self):
        self.x = 50
        self.y = SCREEN_HEIGHT // 2
        self.velocity = 0
        self.size = BIRD_SIZE
        
        # Load bird images if they exist
        try:
            original_images = [
                pygame.image.load("assets/bird_frame_1.png").convert_alpha(),
                pygame.image.load("assets/bird_frame_2.png").convert_alpha(),
                pygame.image.load("assets/bird_frame_3.png").convert_alpha()
            ]
            # Scale bird images to reasonable size
            self.bird_images = [pygame.transform.scale(img, (34, 24)) for img in original_images]
            self.use_images = True
            print("Bird images loaded successfully!")
        except:
            self.bird_images = []
            self.use_images = False
            print("Bird images not found, using simple graphics")
        
        self.current_frame = 0
        self.animation_speed = 0.1
        self.bird_mask = None
        
    def jump(self):
        self.velocity = JUMP_STRENGTH
        
    def update(self):
        self.velocity += GRAVITY
        self.y += self.velocity
        
        # Animate bird if using images
        if self.use_images:
            self.current_frame += self.animation_speed
            if self.current_frame >= len(self.bird_images):
                self.current_frame = 0
        
    def draw(self, screen):
        if self.use_images and self.bird_images:
            # Draw bird image
            current_image = self.bird_images[int(self.current_frame)]
            screen.blit(current_image, (self.x - current_image.get_width()//2, self.y - current_image.get_height()//2))
            # Create mask for collision detection
            self.bird_mask = pygame.mask.from_surface(current_image)
        else:
            # Draw simple bird without outline
            pygame.draw.circle(screen, YELLOW, (int(self.x), int(self.y)), self.size // 2)
            pygame.draw.circle(screen, BLACK, (int(self.x + 5), int(self.y - 5)), 3)
            # Create a simple circular mask for collision
            temp_surface = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            pygame.draw.circle(temp_surface, (255, 255, 255), (self.size//2, self.size//2), self.size//2)
            self.bird_mask = pygame.mask.from_surface(temp_surface)
        
    def get_rect(self):
        if self.use_images and self.bird_images:
            img = self.bird_images[int(self.current_frame)]
            return pygame.Rect(self.x - img.get_width()//2, self.y - img.get_height()//2, img.get_width(), img.get_height())
        else:
            return pygame.Rect(self.x - self.size // 2, self.y - self.size // 2, self.size, self.size)

class Pipe:
    def __init__(self, x, last_gap_center=None):
        self.x = x
        self.passed = False
        
        # Classic Flappy Bird gap system with reasonable difficulty
        # Create alternating gap positions for challenge
        if last_gap_center is None:
            gap_center = random.randint(150, SCREEN_HEIGHT - 150)
        else:
            screen_middle = SCREEN_HEIGHT // 2
            if last_gap_center < screen_middle:
                gap_center = random.randint(screen_middle + 50, SCREEN_HEIGHT - 150)
            else:
                gap_center = random.randint(150, screen_middle - 50)
        
        # Variable gap sizes for balanced difficulty
        gap_chance = random.random()
        if gap_chance < 0.6:  # 60% chance for normal gaps
            self.gap_size = random.randint(120, 140)
        elif gap_chance < 0.8:  # 20% chance for smaller gaps
            self.gap_size = random.randint(100, 120)
        else:  # 20% chance for larger gaps
            self.gap_size = random.randint(140, 160)
        
        self.gap_center = gap_center
        self.gap_top = gap_center - self.gap_size // 2
        self.gap_bottom = gap_center + self.gap_size // 2
        
        # Top pipe (extends down from top of screen)
        self.top_height = self.gap_top
        
        # Bottom pipe (extends up from bottom of screen)
        self.bottom_y = self.gap_bottom
        self.bottom_height = SCREEN_HEIGHT - self.gap_bottom
        
        # Load pipe image if it exists
        try:
            original_pipe = pygame.image.load("assets/pipe.png").convert_alpha()
            self.pipe_image = pygame.transform.scale(original_pipe, (PIPE_WIDTH, original_pipe.get_height()))
            self.use_image = True
            print("Pipe image loaded!")
        except:
            self.pipe_image = None
            self.use_image = False
        
        # Store pipe masks for pixel-perfect collision
        self.pipe_masks = []
        
    def update(self):
        self.x -= PIPE_SPEED
        
    def draw(self, screen):
        # Clear previous masks
        self.pipe_masks = []
        
        if self.use_image and self.pipe_image:
            # Draw top pipe (always exists)
            top_pipe = pygame.transform.flip(self.pipe_image, False, True)
            top_pipe = pygame.transform.scale(top_pipe, (PIPE_WIDTH, self.top_height))
            screen.blit(top_pipe, (self.x, 0))
            # Create mask for collision detection
            mask = pygame.mask.from_surface(top_pipe)
            self.pipe_masks.append((mask, self.x, 0))
            
            # Draw bottom pipe (always exists)
            bottom_pipe = pygame.transform.scale(self.pipe_image, (PIPE_WIDTH, self.bottom_height))
            screen.blit(bottom_pipe, (self.x, self.bottom_y))
            # Create mask for collision detection
            mask = pygame.mask.from_surface(bottom_pipe)
            self.pipe_masks.append((mask, self.x, self.bottom_y))
        else:
            # Draw simple pipes without outlines
            pygame.draw.rect(screen, GREEN, (self.x, 0, PIPE_WIDTH, self.top_height))
            pygame.draw.rect(screen, GREEN, (self.x, self.bottom_y, PIPE_WIDTH, self.bottom_height))
        
    def get_rects(self):
        # Always return both pipe rectangles
        top_rect = pygame.Rect(self.x, 0, PIPE_WIDTH, self.top_height)
        bottom_rect = pygame.Rect(self.x, self.bottom_y, PIPE_WIDTH, self.bottom_height)
        return [top_rect, bottom_rect]
        
    def is_off_screen(self):
        return self.x + PIPE_WIDTH < 0

class Ground:
    def __init__(self):
        self.x = 0
        self.y = SCREEN_HEIGHT - 50
        self.speed = PIPE_SPEED
        
        # Load ground image if it exists
        try:
            self.ground_image = pygame.image.load("assets/ground.png").convert_alpha()
            self.ground_image = pygame.transform.scale(self.ground_image, (SCREEN_WIDTH * 2, 50))
            self.use_image = True
            print("Ground image loaded!")
        except:
            self.ground_image = None
            self.use_image = False
    
    def update(self):
        self.x -= self.speed
        if self.x <= -SCREEN_WIDTH:
            self.x = 0
    
    def draw(self, screen):
        if self.use_image and self.ground_image:
            screen.blit(self.ground_image, (self.x, self.y))
            screen.blit(self.ground_image, (self.x + SCREEN_WIDTH, self.y))
        else:
            pygame.draw.rect(screen, GREEN, (0, self.y, SCREEN_WIDTH, 50))

class FlappyBird:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Flappy Bird")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        
        # Load background image if it exists
        try:
            self.background = pygame.image.load("assets/background.png").convert_alpha()
            self.background = pygame.transform.scale(self.background, (SCREEN_WIDTH, SCREEN_HEIGHT))
            self.use_background = True
            print("Background image loaded!")
        except:
            self.background = None
            self.use_background = False
        
        # Load sound effects if they exist
        try:
            pygame.mixer.init()
            self.wing_flap_sound = pygame.mixer.Sound("assets/wing_flap.mp3")
            self.point_sound = pygame.mixer.Sound("assets/point.mp3")
            self.death_sound = pygame.mixer.Sound("assets/game_die.mp3")
            self.use_sounds = True
            print("Sound effects loaded!")
        except:
            self.use_sounds = False
            print("Sound effects not found")
        
        self.reset_game()
        
    def reset_game(self):
        self.bird = Bird()
        self.pipes = []
        self.ground = Ground()
        self.score = 0
        self.game_over = False
        self.game_started = False
        self.last_gap_center = None  # Track last gap position for challenging placement
        
    def add_pipe(self):
        self.pipes.append(Pipe(SCREEN_WIDTH, self.last_gap_center))
        # Update last gap position
        if self.pipes:
            self.last_gap_center = self.pipes[-1].gap_center
        
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if not self.game_started:
                        self.game_started = True
                        self.add_pipe()
                    elif self.game_over:
                        self.reset_game()
                    else:
                        self.bird.jump()
                        if self.use_sounds:
                            self.wing_flap_sound.play()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if not self.game_started:
                    self.game_started = True
                    self.add_pipe()
                elif self.game_over:
                    self.reset_game()
                else:
                    self.bird.jump()
                    if self.use_sounds:
                        self.wing_flap_sound.play()
        return True
        
    def update(self):
        if not self.game_started or self.game_over:
            return
            
        self.bird.update()
        self.ground.update()
        
        # Add new pipes - increased spacing for better gameplay
        if len(self.pipes) == 0 or self.pipes[-1].x < SCREEN_WIDTH - 200:
            self.add_pipe()
            
        # Update pipes
        for pipe in self.pipes[:]:
            pipe.update()
            if pipe.is_off_screen():
                self.pipes.remove(pipe)
                
        # Check collisions
        bird_rect = self.bird.get_rect()
        
        # Ground and ceiling collision
        if self.bird.y - self.bird.size // 2 <= 0 or self.bird.y + self.bird.size // 2 >= self.ground.y:
            self.game_over = True
            if self.use_sounds:
                self.death_sound.play()
            
        # Pipe collision - pixel-perfect collision detection
        for pipe in self.pipes:
            if pipe.use_image and pipe.pipe_masks and self.bird.bird_mask:
                # Use mask collision for images (pixel-perfect)
                for pipe_mask, pipe_x, pipe_y in pipe.pipe_masks:
                    bird_x = int(self.bird.x - (self.bird.bird_images[int(self.bird.current_frame)].get_width()//2 if self.bird.use_images else self.bird.size//2))
                    bird_y = int(self.bird.y - (self.bird.bird_images[int(self.bird.current_frame)].get_height()//2 if self.bird.use_images else self.bird.size//2))
                    
                    offset = (bird_x - pipe_x, bird_y - pipe_y)
                    if pipe_mask.overlap(self.bird.bird_mask, offset):
                        self.game_over = True
                        if self.use_sounds:
                            self.death_sound.play()
                        break
            else:
                # Fallback to rectangle collision for simple graphics
                pipe_rects = pipe.get_rects()
                for rect in pipe_rects:
                    adjusted_rect = pygame.Rect(rect.x + 2, rect.y, rect.width - 4, rect.height)
                    if bird_rect.colliderect(adjusted_rect):
                        self.game_over = True
                        if self.use_sounds:
                            self.death_sound.play()
                        break
                    
            # Score
            if not pipe.passed and pipe.x + PIPE_WIDTH < self.bird.x:
                pipe.passed = True
                self.score += 1
                if self.use_sounds:
                    self.point_sound.play()
                
    def draw(self):
        # Draw background
        if self.use_background and self.background:
            self.screen.blit(self.background, (0, 0))
        else:
            self.screen.fill(BLUE)
        
        # Draw pipes
        for pipe in self.pipes:
            pipe.draw(self.screen)
            
        # Draw ground
        self.ground.draw(self.screen)
            
        # Draw bird
        if not self.game_over:
            self.bird.draw(self.screen)
        else:
            # Draw dead bird (red circle if no image)
            if not self.bird.use_images:
                pygame.draw.circle(self.screen, RED, (int(self.bird.x), int(self.bird.y)), self.bird.size // 2)
                pygame.draw.circle(self.screen, BLACK, (int(self.bird.x + 5), int(self.bird.y - 5)), 3)
            else:
                self.bird.draw(self.screen)  # Draw bird image even when dead
            
        # Draw score
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, 10))
        
        # Draw instructions
        if not self.game_started:
            start_text = self.font.render("Press SPACE or Click to Start", True, WHITE)
            text_rect = start_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            self.screen.blit(start_text, text_rect)
        elif self.game_over:
            game_over_text = self.font.render("Game Over!", True, WHITE)
            restart_text = self.font.render("Press SPACE or Click to Restart", True, WHITE)
            
            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 30))
            restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 30))
            
            self.screen.blit(game_over_text, game_over_rect)
            self.screen.blit(restart_text, restart_rect)
            
        pygame.display.flip()
        
    def run(self):
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
            
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = FlappyBird()
    game.run()
