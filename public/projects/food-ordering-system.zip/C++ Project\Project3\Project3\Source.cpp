#include <iostream>
#include <cmath>
using namespace std;

double maximum(double a, double b, double c = 0, double d = 0, double e = 0) {

    if (a < 0 || b < 0 || c < 0 || d < 0 || e < 0) {
        std::cerr << "Error: All parameters must be non-negative." << std::endl;
        return -1;
    }

    
    double maxVal = a;
    if (b > maxVal) maxVal = b;
    if (c > maxVal) maxVal = c;
    if (d > maxVal) maxVal = d;
    if (e > maxVal) maxVal = e;

    return maxVal;
}

int main() {
   // Demo of code here:
    double result = maximum(3.8, 8.7, 1.1, 5.8, 9.3);
    cout << "Maximum value: " << result << endl;

    return 0;
}