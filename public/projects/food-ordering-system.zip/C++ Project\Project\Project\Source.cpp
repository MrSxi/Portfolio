#include<iostream>
using namespace std;


int findSumOf2DArray(int arr[3][3]) {
    int sum = 0;
    int ROWS = 3;
    int COLS = 3;
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            sum += arr[i][j];
        }
    }

    return sum;
}

int main() {
    int myArray[3][3];
    
    // Input values into the array
    cout << "Enter elements of the 2D array:" << endl;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> myArray[i][j];
        }
    }

   
    int sum = findSumOf2DArray(myArray);

    cout << "Sum of the 2D array: " << sum << endl;

    return 0;
}
