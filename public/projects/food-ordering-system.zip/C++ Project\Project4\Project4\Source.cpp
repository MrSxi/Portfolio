#include <iostream>

using namespace std;

const double VAT_RATE = 0.05;
const double DELIVERY_COST_PER_KM = 0.5;
// We declared a struct called MenuItems to group several related variables into one place.
struct MenuItem {
    char name[50];
    double price;
};
// We declared a struct called CartItem to to group several related variables into one place.
struct CartItem {
    MenuItem item;
    int quantity;
};
// This function displays the menu.
void displayMenu(MenuItem* menu, int size) {
    cout << "Menu: " << endl;
    for (int i = 0; i < size; ++i) {
        cout << i + 1 << ". " << menu[i].name << " - AED "
            << menu[i].price << endl;
    }
}



int main() {
    // Show the user the avalible restaurants.
    int restaurantChoice;
    cout << "Select a restaurant:" << endl;
    cout << "1. Subway" << endl;
    cout << "2. Papa John's Pizza" << endl;
    cout << "3. M14 Caf�" << endl;
    cout << "4. Starbucks Iced" << endl;
    cout << "5. Dunkin" << endl;

    cin >> restaurantChoice;
    // Checks if the restaurant choice is valid.
    if (restaurantChoice < 1 || restaurantChoice > 5) {
        cout << "Invalid restaurant choice." << endl;
        return 1;
    }

    // Defines menus for different restaurants.
    int menuSize = 5;  // Number of menu items.
    MenuItem* selectedMenu;



    return 0;
}


// This functions displays the users cart.
void addToCart(MenuItem* menu, CartItem* cart, int& cartSize, int menuSize) {
    displayMenu(menu, menuSize);
    int choice;
    int quantity;

    do {
        cout << "Enter the item number to add to your cart (0 to checkout): ";
        cin >> choice;

        if (choice == 0) {
            break;
        }

        if (choice >= 1 && choice <= menuSize) {
            cout << "Enter the quantity: ";
            cin >> quantity;
            cart[cartSize++] = { menu[choice - 1], quantity };
        }
        else {
            cout << "Invalid choice. Please select a valid item." << endl;
        }

    } while (true);
}





// This Function calculates the total cost including VAT and delivery.
double calculateTotalCost(CartItem* cart, int cartSize, double deliveryDistance) {
    double subtotal = 0;
    // Calculates subtotal of items in the cart.
    for (int i = 0; i < cartSize; ++i) {
        subtotal += cart[i].item.price * cart[i].quantity;
    }
    // Calculates delivery cost.
    double deliveryCost = DELIVERY_COST_PER_KM * deliveryDistance;
    // Calculate total cost before VAT
    double totalBeforeVAT = subtotal + deliveryCost;
    // Calculates VAT.
    double vat = totalBeforeVAT * VAT_RATE;
    // Calculate the final total cost
    double total = totalBeforeVAT + vat;

    return total;
}