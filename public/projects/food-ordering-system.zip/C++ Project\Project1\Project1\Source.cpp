#include <iostream>
using namespace std;

int nullcolumns(int x[][4], int rows) {
    int nullColumns = 0;
    bool isNull = true;

    for (int i = 0; i < 4; i++) {
        isNull = true;
        for (int j = 0; j < rows; j++) {
            if (x[j][i] != 0) {
                isNull = false;
                break;
            }
        }
        if (isNull) {
            nullColumns++;
        }
    }
    return nullColumns;

}
int main() {
    int a[3][4] = { {7,	0,	3,	1},
                    {8,	0,	4,	0},
                    {9,	0,	5,	2}
    };
    int b[2][4] = { {1,	0,	3,	0},
                    {5,	0,	7,	0}
    };

    cout << "There are " << nullcolumns(a, 3) << " null columns in a"
        << endl;


    cout << "There are " << nullcolumns(b, 2) << " null columns in b"
        << endl;

    return 0;
}
