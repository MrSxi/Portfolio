import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EventManager {
    private List<Event> events;
    private List<OptionalService> availableServices;
    private List<Discount> availableDiscounts;
    
    public EventManager() {
    this.events = new ArrayList<>();
    this.availableServices = new ArrayList<>();
    this.availableDiscounts = new ArrayList<>();
    
    // Load existing data
    loadData();
    
    // IMPORTANT: Recalculate participant counts after loading
    for (Event event : events) {
        event.recalculateTotalParticipants();
    }
    
    // Initialize defaults if no data exists
    if (availableServices.isEmpty()) {
        initializeDefaultServices();
    }
    if (availableDiscounts.isEmpty()) {
        initializeDefaultDiscounts();
    }
}

// Add this method to sync registrations with events
public void syncRegistrationsWithEvents(List<Registration> allRegistrations) {
    // Clear all existing registrations from events
    for (Event event : events) {
        event.getRegistrations().clear();
        event.recalculateTotalParticipants();
    }
    
    // Re-add all registrations to their respective events
    for (Registration registration : allRegistrations) {
        Event event = registration.getEvent();
        // Find the actual event object in our list
        Event actualEvent = getEventByName(event.getName());
        if (actualEvent != null) {
            actualEvent.addRegistration(registration);
        }
    }
}

    private void initializeDefaultServices() {
        availableServices.add(new OptionalService("Catering", 25.0, "Lunch and refreshments"));
        availableServices.add(new OptionalService("Transportation", 15.0, "Bus transportation to venue"));
        availableServices.add(new OptionalService("Materials", 10.0, "Event materials and handouts"));
        availableServices.add(new OptionalService("Certificate", 5.0, "Participation certificate"));
    }
    
    private void initializeDefaultDiscounts() {
    availableDiscounts.add(new EarlyBirdDiscount(10.0, 7)); // 10% if registered 7 days before
    availableDiscounts.add(new GroupDiscount(15.0, 3)); // 15% for groups of 3 or more (changed from 5)
    availableDiscounts.add(new StaffDiscount()); // 100% discount for staff
}


    
    public void addEvent(Event event) {
        events.add(event);
        saveData();
    }
    
    public void removeEvent(Event event) {
        events.remove(event);
        saveData();
    }
    
    public List<Event> getAllEvents() {
        return new ArrayList<>(events);
    }
    
    public List<Event> getAvailableEvents() {
        return events.stream()
                .filter(Event::hasAvailableSpots)
                .collect(Collectors.toList());
    }
    
    public Event getEventByName(String name) {
        return events.stream()
                .filter(event -> event.getName().equals(name))
                .findFirst()
                .orElse(null);
    }
    
    public List<OptionalService> getAvailableServices() {
        return new ArrayList<>(availableServices);
    }
    
    public List<Discount> getAvailableDiscounts() {
        return new ArrayList<>(availableDiscounts);
    }
    
    public void addOptionalService(OptionalService service) {
        availableServices.add(service);
    }
    
    public void addDiscount(Discount discount) {
        availableDiscounts.add(discount);
    }
    
    // Data persistence methods
    private void loadData() {
        this.events = DataPersistence.loadEvents();
    }
    
    private void saveData() {
        DataPersistence.saveEvents(events);
    }
    
    // Method to save data when application closes
    public void saveAllData() {
        saveData();
    }
}
