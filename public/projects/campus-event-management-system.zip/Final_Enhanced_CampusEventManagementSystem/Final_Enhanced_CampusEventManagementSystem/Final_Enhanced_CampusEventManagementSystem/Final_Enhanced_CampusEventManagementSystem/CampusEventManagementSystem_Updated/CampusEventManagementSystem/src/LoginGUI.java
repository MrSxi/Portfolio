import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class LoginGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> userTypeCombo;
    private JButton loginButton;
    private JButton cancelButton;
    
    // Updated credentials
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";
    private static final String USER_USERNAME = "user";
    private static final String USER_PASSWORD = "user123";
    
    public LoginGUI() {
        initializeGUI();
    }
    
    private void initializeGUI() {
        setTitle("Campus Event Management System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 350);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create main panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Title
        JLabel titleLabel = new JLabel("Campus Event Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);
        
        // Username
        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(new JLabel("Username:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        usernameField = new JTextField(25);
        mainPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("Password:"), gbc);
        
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        passwordField = new JPasswordField(25);
        mainPanel.add(passwordField, gbc);
        
        // User Type
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(new JLabel("Login Type:"), gbc);
        
        gbc.gridx = 1;
        userTypeCombo = new JComboBox<>(new String[]{"Student & Staff Portal", "Admin Portal"});
        mainPanel.add(userTypeCombo, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        loginButton = new JButton("Login");
        cancelButton = new JButton("Cancel");
        
        // Use lambda expressions instead of inner class
        loginButton.addActionListener(e -> handleLogin());
        cancelButton.addActionListener(e -> System.exit(0));
        
        // Enter key support
        getRootPane().setDefaultButton(loginButton);
        
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);
        
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(buttonPanel, gbc);
        
       
        
        gbc.gridy = 5;
        gbc.fill = GridBagConstraints.HORIZONTAL;
       
        
        add(mainPanel);
    }
    
    // Extract the login logic to a separate method
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String loginType = (String) userTypeCombo.getSelectedItem();
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter both username and password.", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        final boolean isValidLogin;
        final boolean isAdmin;
        
        if (loginType.equals("Admin Portal") && username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
            isValidLogin = true;
            isAdmin = true;
        } else if (loginType.equals("Student & Staff Portal") && username.equals(USER_USERNAME) && password.equals(USER_PASSWORD)) {
            isValidLogin = true;
            isAdmin = false; // This is the key - Student/Staff portal should NOT have admin privileges
        } else {
            isValidLogin = false;
            isAdmin = false;
        }
        
        if (isValidLogin) {
            // Close login window
            dispose();
            
            // IMPORTANT: Pass isAdmin as the isStaff parameter
            // isAdmin = true means full admin privileges (all tabs)
            // isAdmin = false means limited privileges (registration only)
            SwingUtilities.invokeLater(() -> {
                new CampusEventManagementGUI(isAdmin, username).setVisible(true);
            });
        } else {
            JOptionPane.showMessageDialog(this, 
                "Invalid username, password, or login type combination.", 
                "Login Failed", JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }
}
