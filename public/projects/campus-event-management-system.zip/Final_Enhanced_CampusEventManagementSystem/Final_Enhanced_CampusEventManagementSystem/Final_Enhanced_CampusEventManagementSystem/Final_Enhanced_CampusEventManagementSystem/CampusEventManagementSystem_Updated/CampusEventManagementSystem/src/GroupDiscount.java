public class GroupDiscount extends Discount {
    private double discountPercentage;
    private int minimumGroupSize;
    
    public GroupDiscount(double discountPercentage, int minimumGroupSize) {
        super("Group Discount", "Discount for group registration");
        this.discountPercentage = discountPercentage;
        this.minimumGroupSize = minimumGroupSize;
    }
    
    public double getDiscountPercentage() { return discountPercentage; }
    public int getMinimumGroupSize() { return minimumGroupSize; }
    
    public void setDiscountPercentage(double discountPercentage) { this.discountPercentage = discountPercentage; }
    public void setMinimumGroupSize(int minimumGroupSize) { this.minimumGroupSize = minimumGroupSize; }
    
    @Override
    public double calculateDiscount(double totalAmount) {
        return totalAmount * (discountPercentage / 100.0);
    }
    
    @Override
    public boolean isApplicable(Registration registration) {
        return registration.getGroupSize() >= minimumGroupSize;
    }
    
    @Override
    public String toString() {
        return super.toString() + " (" + discountPercentage + "% for groups of " + minimumGroupSize + " or more)";
    }
}
