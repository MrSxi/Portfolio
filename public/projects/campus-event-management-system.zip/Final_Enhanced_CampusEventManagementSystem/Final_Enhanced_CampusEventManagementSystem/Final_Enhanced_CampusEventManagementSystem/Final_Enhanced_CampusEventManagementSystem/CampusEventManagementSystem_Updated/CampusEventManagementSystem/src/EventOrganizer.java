public class EventOrganizer extends User {
    private String department;
    
    public EventOrganizer(String userId, String name, String email, String department) {
        super(userId, name, email);
        this.department = department;
    }
    
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    
    @Override
    public String getUserType() {
        return "Event Organizer";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - Department: " + department;
    }
}

