import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class Event implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String name;
    protected LocalDate date;
    protected String venue;
    protected int capacity;
    protected double baseFee;
    protected List<Registration> registrations;
    protected int totalRegisteredParticipants; // Track total participants, not just registrations
    
    public Event(String name, LocalDate date, String venue, int capacity, double baseFee) {
        this.name = name;
        this.date = date;
        this.venue = venue;
        this.capacity = capacity;
        this.baseFee = baseFee;
        this.registrations = new ArrayList<>();
        this.totalRegisteredParticipants = 0;
    }
    
    // Getters
    public String getName() { return name; }
    public LocalDate getDate() { return date; }
    public String getVenue() { return venue; }
    public int getCapacity() { return capacity; }
    public double getBaseFee() { return baseFee; }
    public List<Registration> getRegistrations() { return registrations; }
    public int getTotalRegisteredParticipants() { return totalRegisteredParticipants; }
    
    // Setters
    public void setName(String name) { this.name = name; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setVenue(String venue) { this.venue = venue; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public void setBaseFee(double baseFee) { this.baseFee = baseFee; }
    
    // Methods
    public boolean hasAvailableSpots() {
        return totalRegisteredParticipants < capacity;
    }
    
    public int getAvailableSpots() {
        return capacity - totalRegisteredParticipants;
    }
    
    public boolean canAccommodateGroup(int groupSize) {
        return getAvailableSpots() >= groupSize;
    }
    
    public void addRegistration(Registration registration) {
        if (canAccommodateGroup(registration.getGroupSize())) {
            registrations.add(registration);
            totalRegisteredParticipants += registration.getGroupSize();
        } else {
            throw new IllegalStateException("Event cannot accommodate group of size " + registration.getGroupSize() + 
                                          ". Available spots: " + getAvailableSpots());
        }
    }
    
    public void removeRegistration(Registration registration) {
        if (registrations.remove(registration)) {
            totalRegisteredParticipants -= registration.getGroupSize();
        }
    }
    
    // Method to recalculate total participants (useful for data consistency)
public void recalculateTotalParticipants() {
    totalRegisteredParticipants = 0;
    for (Registration registration : registrations) {
        totalRegisteredParticipants += registration.getGroupSize();
    }
    System.out.println("DEBUG: Event " + name + " recalculated participants: " + totalRegisteredParticipants);
}

    public abstract String getEventType();
    
    @Override
    public String toString() {
        return name + " (" + getEventType() + ") - " + date + " at " + venue;
    }
}
