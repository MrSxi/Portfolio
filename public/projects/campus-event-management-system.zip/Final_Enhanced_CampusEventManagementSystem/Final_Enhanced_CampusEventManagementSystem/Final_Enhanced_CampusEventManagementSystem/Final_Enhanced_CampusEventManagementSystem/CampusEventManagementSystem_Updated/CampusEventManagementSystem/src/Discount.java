import java.io.Serializable;

public abstract class Discount implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String discountName;
    protected String description;
    
    public Discount(String discountName, String description) {
        this.discountName = discountName;
        this.description = description;
    }
    
    // Getters
    public String getDiscountName() { return discountName; }
    public String getDescription() { return description; }
    
    // Setters
    public void setDiscountName(String discountName) { this.discountName = discountName; }
    public void setDescription(String description) { this.description = description; }
    
    public abstract double calculateDiscount(double totalAmount);
    public abstract boolean isApplicable(Registration registration);
    
    @Override
    public String toString() {
        return discountName + " - " + description;
    }
}

