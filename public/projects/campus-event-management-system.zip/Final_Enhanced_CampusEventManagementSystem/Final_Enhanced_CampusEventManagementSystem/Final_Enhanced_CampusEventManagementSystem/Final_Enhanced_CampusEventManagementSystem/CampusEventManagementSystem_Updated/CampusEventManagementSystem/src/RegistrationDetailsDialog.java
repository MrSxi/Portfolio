import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class RegistrationDetailsDialog extends JDialog {
    private Registration registration;
    
    public RegistrationDetailsDialog(JFrame parent, Registration registration) {
        super(parent, "Registration Details", true);
        this.registration = registration;
        initializeDialog();
    }
    
    private void initializeDialog() {
        setSize(700, 600);
        setLocationRelativeTo(getParent());
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Registration info
        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        infoPanel.add(new JLabel("Registration ID:"), gbc);
        gbc.gridx = 1;
        infoPanel.add(new JLabel(registration.getRegistrationId()), gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        infoPanel.add(new JLabel("Event:"), gbc);
        gbc.gridx = 1;
        infoPanel.add(new JLabel(registration.getEvent().getName()), gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        infoPanel.add(new JLabel("Event Date:"), gbc);
        gbc.gridx = 1;
        infoPanel.add(new JLabel(registration.getEvent().getDate().toString()), gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        infoPanel.add(new JLabel("Registration Date:"), gbc);
        gbc.gridx = 1;
        infoPanel.add(new JLabel(registration.getRegistrationDate().toString()), gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        infoPanel.add(new JLabel("Group Size:"), gbc);
        gbc.gridx = 1;
        infoPanel.add(new JLabel(String.valueOf(registration.getGroupSize())), gbc);
        
        // All Participants Details Section
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.3;
        
        JPanel participantsPanel = new JPanel(new BorderLayout());
        participantsPanel.setBorder(BorderFactory.createTitledBorder("All Participants"));
        
        // Create table for participants
        String[] participantColumns = {"#", "Name", "Email", "ID", "Type"};
        DefaultTableModel participantTableModel = new DefaultTableModel(participantColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable participantTable = new JTable(participantTableModel);
        participantTable.setRowHeight(25);
        participantTable.getColumnModel().getColumn(0).setPreferredWidth(30);  // #
        participantTable.getColumnModel().getColumn(1).setPreferredWidth(120); // Name
        participantTable.getColumnModel().getColumn(2).setPreferredWidth(150); // Email
        participantTable.getColumnModel().getColumn(3).setPreferredWidth(60);  // ID
        participantTable.getColumnModel().getColumn(4).setPreferredWidth(80);  // Type
        
        // Populate participant table
        List<Participant> allParticipants = registration.getAllParticipants();
        if (allParticipants != null && !allParticipants.isEmpty()) {
            for (int i = 0; i < allParticipants.size(); i++) {
                Participant p = allParticipants.get(i);
                if (p != null) {
                    String participantNumber = String.valueOf(i + 1);
                    if (i == 0) {
                        participantNumber += " (Primary)";
                    }
                    participantTableModel.addRow(new Object[]{
                        participantNumber,
                        p.getName(),
                        p.getEmail(),
                        p.getStudentId(),
                        p.getParticipantType()
                    });
                }
            }
        } else if (registration.getParticipant() != null) {
            // Fallback for old format
            Participant p = registration.getParticipant();
            participantTableModel.addRow(new Object[]{
                "1 (Primary)",
                p.getName(),
                p.getEmail(),
                p.getStudentId(),
                p.getParticipantType()
            });
        }
        
        JScrollPane participantScrollPane = new JScrollPane(participantTable);
        participantScrollPane.setPreferredSize(new Dimension(600, 120));
        participantsPanel.add(participantScrollPane, BorderLayout.CENTER);
        
        infoPanel.add(participantsPanel, gbc);
        
        // Bill details
        gbc.gridx = 0; gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 0.7;
        
        JTextArea billDetailsArea = new JTextArea(registration.getBillDetails());
        billDetailsArea.setEditable(false);
        billDetailsArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane billScrollPane = new JScrollPane(billDetailsArea);
        billScrollPane.setBorder(BorderFactory.createTitledBorder("Bill Details"));
        billScrollPane.setPreferredSize(new Dimension(600, 200));
        
        infoPanel.add(billScrollPane, gbc);
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(closeButton);
        
        mainPanel.add(infoPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    public static void showDialog(JFrame parent, Registration registration) {
        RegistrationDetailsDialog dialog = new RegistrationDetailsDialog(parent, registration);
        dialog.setVisible(true);
    }
}
