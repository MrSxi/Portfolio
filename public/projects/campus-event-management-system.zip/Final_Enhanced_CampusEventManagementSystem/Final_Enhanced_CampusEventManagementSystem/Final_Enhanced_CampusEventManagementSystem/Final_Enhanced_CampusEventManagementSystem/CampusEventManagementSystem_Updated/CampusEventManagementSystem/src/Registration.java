import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Registration implements Serializable {
    private static final long serialVersionUID = 1L;
    private String registrationId;
    private Participant participant; // Primary participant
    private List<Participant> allParticipants; // All participants in the group
    private Event event;
    private LocalDate registrationDate;
    private List<OptionalService> selectedServices;
    private List<Discount> appliedDiscounts;
    private double netAmount;
    private String billDetails;
    private int groupSize;
    
    // Private constructor for Builder pattern
    private Registration(RegistrationBuilder builder) {
        this.registrationId = builder.registrationId;
        this.participant = builder.participant;
        this.allParticipants = new ArrayList<>(builder.allParticipants);
        this.event = builder.event;
        this.registrationDate = builder.registrationDate;
        this.selectedServices = new ArrayList<>(builder.selectedServices);
        this.appliedDiscounts = new ArrayList<>(builder.appliedDiscounts);
        this.groupSize = builder.groupSize;
        calculateFees();
    }
    
    // Getters
    public String getRegistrationId() { return registrationId; }
    public Participant getParticipant() { return participant; }
    public List<Participant> getAllParticipants() { return new ArrayList<>(allParticipants); }
    public Event getEvent() { return event; }
    public LocalDate getRegistrationDate() { return registrationDate; }
    public List<OptionalService> getSelectedServices() { return new ArrayList<>(selectedServices); }
    public List<Discount> getAppliedDiscounts() { return new ArrayList<>(appliedDiscounts); }
    public double getNetAmount() { return netAmount; }
    public String getBillDetails() { return billDetails; }
    public int getGroupSize() { return groupSize; }
    
    private void calculateFees() {
    double baseFee = event.getBaseFee() * groupSize;
    double servicesFee = selectedServices.stream()
            .mapToDouble(service -> service.getCost() * groupSize)
            .sum();
    
    double totalBeforeDiscount = baseFee + servicesFee;
    double totalDiscount = 0.0;
    
    // Apply discounts in order of priority (Staff discount should be applied last and override others)
    List<Discount> applicableDiscounts = new ArrayList<>();
    boolean hasStaffDiscount = false;
    
    for (Discount discount : appliedDiscounts) {
        if (discount.isApplicable(this)) {
            applicableDiscounts.add(discount);
            if (discount instanceof StaffDiscount) {
                hasStaffDiscount = true;
            }
        }
    }
    
    // If staff discount applies, only use that (makes everything free)
    if (hasStaffDiscount) {
        for (Discount discount : applicableDiscounts) {
            if (discount instanceof StaffDiscount) {
                totalDiscount = discount.calculateDiscount(totalBeforeDiscount);
                break; // Staff discount overrides all others
            }
        }
    } else {
        // Apply other discounts normally
        for (Discount discount : applicableDiscounts) {
            totalDiscount += discount.calculateDiscount(totalBeforeDiscount);
        }
    }
    
    this.netAmount = Math.max(0, totalBeforeDiscount - totalDiscount); // Ensure non-negative
    generateBillDetails(baseFee, servicesFee, totalBeforeDiscount, totalDiscount, applicableDiscounts, hasStaffDiscount);
}

private void generateBillDetails(double baseFee, double servicesFee, double totalBeforeDiscount, 
                               double totalDiscount, List<Discount> applicableDiscounts, boolean hasStaffDiscount) {
    StringBuilder bill = new StringBuilder();
    bill.append("=".repeat(50)).append("\n");
    bill.append("           REGISTRATION BILL\n");
    bill.append("=".repeat(50)).append("\n");
    bill.append("Registration ID: ").append(registrationId).append("\n");
    bill.append("Event: ").append(event.getName()).append("\n");
    bill.append("Date: ").append(event.getDate()).append("\n");
    bill.append("Venue: ").append(event.getVenue()).append("\n");
    bill.append("Group Size: ").append(groupSize).append("\n");
    bill.append("-".repeat(50)).append("\n");
    
    // Show all participants
    bill.append("PARTICIPANTS:\n");
    for (int i = 0; i < allParticipants.size(); i++) {
        Participant p = allParticipants.get(i);
        bill.append(String.format("%d. %s (ID: %s, Email: %s, Type: %s)%s\n", 
            i + 1, p.getName(), p.getStudentId(), p.getEmail(), p.getParticipantType(),
            i == 0 ? " [Primary]" : ""));
    }
    bill.append("-".repeat(50)).append("\n");
    
    bill.append("FEE BREAKDOWN:\n");
    bill.append(String.format("Base Fee: $%.2f x %d = $%.2f\n", 
        event.getBaseFee(), groupSize, baseFee));
    
    if (!selectedServices.isEmpty()) {
        bill.append("Optional Services:\n");
        for (OptionalService service : selectedServices) {
            double serviceCost = service.getCost() * groupSize;
            bill.append(String.format("  %s: $%.2f x %d = $%.2f\n", 
                service.getServiceName(), service.getCost(), groupSize, serviceCost));
        }
    }
    
    bill.append(String.format("Subtotal: $%.2f\n", totalBeforeDiscount));
    
    if (totalDiscount > 0) {
        bill.append("Discounts Applied:\n");
        
        if (hasStaffDiscount) {
            // Show staff discount prominently
            bill.append(String.format("  %s: -$%.2f (FREE REGISTRATION!)\n", 
                "Staff Registration Discount", totalDiscount));
        } else {
            // Show other discounts
            for (Discount discount : applicableDiscounts) {
                bill.append(String.format("  %s: -$%.2f\n", 
                    discount.getDiscountName(), discount.calculateDiscount(totalBeforeDiscount)));
            }
        }
        bill.append(String.format("Total Discount: -$%.2f\n", totalDiscount));
    }
    
    bill.append("=".repeat(50)).append("\n");
    if (hasStaffDiscount) {
        bill.append("NET AMOUNT: $0.00 (FREE FOR STAFF!)\n");
    } else {
        bill.append(String.format("NET AMOUNT: $%.2f\n", netAmount));
    }
    bill.append("=".repeat(50)).append("\n");
    
    if (hasStaffDiscount) {
        bill.append("\n*** STAFF REGISTRATION - NO PAYMENT REQUIRED ***\n");
    }
    
    this.billDetails = bill.toString();
}

    // Builder Pattern Implementation
    public static class RegistrationBuilder {
        private String registrationId;
        private Participant participant;
        private List<Participant> allParticipants;
        private Event event;
        private LocalDate registrationDate;
        private List<OptionalService> selectedServices;
        private List<Discount> appliedDiscounts;
        private int groupSize;
        
        public RegistrationBuilder(String registrationId, Participant participant, Event event) {
            this.registrationId = registrationId;
            this.participant = participant;
            this.event = event;
            this.registrationDate = LocalDate.now();
            this.selectedServices = new ArrayList<>();
            this.appliedDiscounts = new ArrayList<>();
            this.allParticipants = new ArrayList<>();
            this.allParticipants.add(participant); // Add primary participant
            this.groupSize = 1;
        }
        
        public RegistrationBuilder addOptionalService(OptionalService service) {
            this.selectedServices.add(service);
            return this;
        }
        
        public RegistrationBuilder addDiscount(Discount discount) {
            this.appliedDiscounts.add(discount);
            return this;
        }
        
        public RegistrationBuilder setGroupSize(int groupSize) {
            this.groupSize = groupSize;
            return this;
        }
        
        public RegistrationBuilder addParticipant(Participant participant) {
            this.allParticipants.add(participant);
            return this;
        }
        
        public RegistrationBuilder setAllParticipants(List<Participant> participants) {
            this.allParticipants = new ArrayList<>(participants);
            if (!participants.isEmpty()) {
                this.participant = participants.get(0); // First one is primary
            }
            return this;
        }
        
        public Registration build() {
            // Ensure we have the right number of participants
            while (allParticipants.size() < groupSize) {
                // This shouldn't happen with proper validation, but just in case
                allParticipants.add(participant);
            }
            return new Registration(this);
        }
    }
}
