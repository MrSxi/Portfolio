import java.time.LocalDate;

public class Workshop extends Event {
    private String instructor;
    private String materials;
    
    public Workshop(String name, LocalDate date, String venue, int capacity, double baseFee, String instructor, String materials) {
        super(name, date, venue, capacity, baseFee);
        this.instructor = instructor;
        this.materials = materials;
    }
    
    public String getInstructor() { return instructor; }
    public String getMaterials() { return materials; }
    
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public void setMaterials(String materials) { this.materials = materials; }
    
    @Override
    public String getEventType() {
        return "Workshop";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - Instructor: " + instructor + ", Materials: " + materials;
    }
}

