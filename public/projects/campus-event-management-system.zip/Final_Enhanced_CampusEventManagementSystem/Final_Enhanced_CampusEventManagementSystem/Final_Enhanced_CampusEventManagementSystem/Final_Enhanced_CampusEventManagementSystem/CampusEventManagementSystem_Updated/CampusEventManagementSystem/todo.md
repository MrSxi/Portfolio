## Todo List for Campus Event Management System Assignment

### Phase 1: Requirements Analysis and System Design
- [x] Thoroughly read and understand the provided PDF document.
- [x] Extract all functional and non-functional requirements.
- [x] Identify key entities and their relationships.
- [x] Define the scope of the system.

### Phase 2: UML Diagrams Creation
- [x] Create Use Case Diagram.
- [x] Create Class Diagram.
- [x] Create Sequence Diagrams for critical operations (event creation, registration, fee calculation).

### Phase 3: Design Pattern Selection and Integration
- [x] Choose one suitable design pattern from the given list.
- [x] Justify the selection of the design pattern.
- [x] Incorporate the chosen design pattern into the class diagram.

### Phase 4: Java Swing GUI Implementation
- [x] Implement the GUI using Java Swing.
- [x] Implement event handling, validations, and accurate fee calculations.
- [x] Ensure implementation closely follows UML design.

### Phase 5: Testing and Documentation
- [x] Test the application thoroughly.
- [x] Prepare documentation for Q&A interview.

### Phase 6: Final Package and Delivery
- [ ] Create a zip folder with all source code, UML diagrams, and supporting documentation.


