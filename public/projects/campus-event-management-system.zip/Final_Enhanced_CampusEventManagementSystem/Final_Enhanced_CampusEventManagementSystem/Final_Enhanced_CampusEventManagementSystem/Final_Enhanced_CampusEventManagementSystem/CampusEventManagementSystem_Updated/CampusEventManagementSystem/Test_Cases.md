# Test Cases for Campus Event Management System (Updated)

## Data Persistence Test Cases

### TC001: Event Persistence
**Test Steps:**
1. Create a new event
2. Close the application
3. Reopen the application
4. Check if the event still exists

**Expected Result:** Event persists across application sessions

### TC002: Registration Persistence
**Test Steps:**
1. Create an event and register a participant
2. Close the application
3. Reopen the application
4. Check if registration and updated event capacity are maintained

**Expected Result:** Registration persists and event shows correct registration count

### TC003: Data File Creation
**Test Steps:**
1. Run application for first time
2. Create events and registrations
3. Check for creation of .ser files

**Expected Result:** events_data.ser and registrations_data.ser files created

## Enhanced Validation Test Cases

### TC004: Email Validation
**Test Steps:**
1. Try to register with email "testuser" (no @)
2. Try to register with email "test@university.edu"

**Expected Result:** First attempt rejected, second attempt accepted

### TC005: ID Validation
**Test Steps:**
1. Try to register with ID "ABC123" (non-numeric)
2. Try to register with ID "12345" (numeric)

**Expected Result:** First attempt rejected, second attempt accepted

### TC006: Capacity Validation
**Test Steps:**
1. Create event with capacity 2
2. Register 2 participants
3. Try to register 1 more participant

**Expected Result:** Third registration rejected with capacity message

### TC007: Group Size Validation
**Test Steps:**
1. Create event with 3 available spots
2. Try to register group of 5 people

**Expected Result:** Registration rejected with available spots message

## Group Booking Test Cases

### TC008: Group Fee Calculation
**Test Steps:**
1. Register group of 3 people for event with $50 base fee
2. Add catering service ($25)
3. Calculate total

**Expected Result:** 
- Base fee: 3 × $50 = $150
- Catering: 3 × $25 = $75
- Total: $225 (before discounts)

### TC009: Group Discount Application
**Test Steps:**
1. Register group of 5 people
2. Check if group discount (15%) is applied

**Expected Result:** Group discount applied to total amount

### TC010: Detailed Bill for Groups
**Test Steps:**
1. Register group with optional services
2. Check bill details

**Expected Result:** Bill shows per-person costs and total costs clearly

## Update Functionality Test Cases

### TC011: Event Update Success
**Test Steps:**
1. Create event with capacity 10
2. Register 2 participants
3. Update event name and increase capacity to 15

**Expected Result:** Event updated successfully, registrations preserved

### TC012: Capacity Reduction Prevention
**Test Steps:**
1. Create event with capacity 10
2. Register 5 participants
3. Try to update capacity to 3

**Expected Result:** Update rejected with error message

### TC013: Event Type Change Prevention
**Test Steps:**
1. Create a Seminar event
2. Try to update it to Workshop type

**Expected Result:** Update rejected, advised to create new event

## UI Refresh Test Cases

### TC014: Table Refresh After Registration
**Test Steps:**
1. Create event with capacity 5
2. Register participant
3. Check if event table shows updated registration count

**Expected Result:** Event table immediately shows increased registration count

### TC015: Available Events Update
**Test Steps:**
1. Create event with capacity 1
2. Register 1 participant
3. Check if event disappears from registration dropdown

**Expected Result:** Event no longer appears in available events list

## Error Handling Test Cases

### TC016: Clear Error Messages
**Test Steps:**
1. Trigger various validation errors
2. Check message clarity

**Expected Result:** All error messages are specific and helpful

### TC017: Form State After Error
**Test Steps:**
1. Fill registration form with invalid data
2. Submit and get error
3. Check if form data is preserved

**Expected Result:** Valid form data remains, only invalid fields need correction

## Integration Test Cases

### TC018: Complete Workflow with Persistence
**Test Steps:**
1. Create event
2. Register multiple participants
3. Close and reopen application
4. Verify all data intact
5. Register more participants
6. Update event details

**Expected Result:** All operations work seamlessly with data persistence

### TC019: Multiple Group Registrations
**Test Steps:**
1. Create event with capacity 20
2. Register group of 5
3. Register group of 3
4. Register individual participant
5. Check capacity calculations

**Expected Result:** Capacity correctly reduced by 9 (5+3+1)

### TC020: Mixed Event Types Persistence
**Test Steps:**
1. Create one of each event type
2. Register participants for each
3. Close and reopen application
4. Verify all event types and registrations preserved

**Expected Result:** All event types and their specific data preserved

## Performance Test Cases

### TC021: Large Data Set Persistence
**Test Steps:**
1. Create 50+ events
2. Register 100+ participants
3. Close and reopen application
4. Check load time and data integrity

**Expected Result:** Reasonable load time, all data intact

### TC022: Concurrent Operations
**Test Steps:**
1. Rapidly create events and registrations
2. Check for data consistency

**Expected Result:** All operations complete successfully

## Edge Cases

### TC023: Zero Capacity Event
**Test Steps:**
1. Try to create event with capacity 0
2. Check behavior

**Expected Result:** Appropriate handling of edge case

### TC024: Maximum Group Size
**Test Steps:**
1. Create event with large capacity
2. Try to register very large group

**Expected Result:** System handles large numbers appropriately

### TC025: Data File Corruption Recovery
**Test Steps:**
1. Manually corrupt .ser files
2. Start application
3. Check recovery behavior

**Expected Result:** Application starts with empty data, no crashes

