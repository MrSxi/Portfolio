import java.time.LocalDate;

public class SportsEvent extends Event {
    private String sportType;
    private String equipment;
    
    public SportsEvent(String name, LocalDate date, String venue, int capacity, double baseFee, String sportType, String equipment) {
        super(name, date, venue, capacity, baseFee);
        this.sportType = sportType;
        this.equipment = equipment;
    }
    
    public String getSportType() { return sportType; }
    public String getEquipment() { return equipment; }
    
    public void setSportType(String sportType) { this.sportType = sportType; }
    public void setEquipment(String equipment) { this.equipment = equipment; }
    
    @Override
    public String getEventType() {
        return "Sports Event";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - Sport: " + sportType + ", Equipment: " + equipment;
    }
}

