import java.time.LocalDate;

public class Seminar extends Event {
    private String speaker;
    private String topic;
    
    public Seminar(String name, LocalDate date, String venue, int capacity, double baseFee, String speaker, String topic) {
        super(name, date, venue, capacity, baseFee);
        this.speaker = speaker;
        this.topic = topic;
    }
    
    public String getSpeaker() { return speaker; }
    public String getTopic() { return topic; }
    
    public void setSpeaker(String speaker) { this.speaker = speaker; }
    public void setTopic(String topic) { this.topic = topic; }
    
    @Override
    public String getEventType() {
        return "Seminar";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - Speaker: " + speaker + ", Topic: " + topic;
    }
}

