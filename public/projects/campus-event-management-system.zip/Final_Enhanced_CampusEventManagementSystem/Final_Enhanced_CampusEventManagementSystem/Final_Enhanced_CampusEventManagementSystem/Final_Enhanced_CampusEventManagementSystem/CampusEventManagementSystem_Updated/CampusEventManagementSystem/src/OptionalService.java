import java.io.Serializable;

public class OptionalService implements Serializable {
    private static final long serialVersionUID = 1L;
    private String serviceName;
    private double cost;
    private String description;
    
    public OptionalService(String serviceName, double cost, String description) {
        this.serviceName = serviceName;
        this.cost = cost;
        this.description = description;
    }
    
    // Getters
    public String getServiceName() { return serviceName; }
    public double getCost() { return cost; }
    public String getDescription() { return description; }
    
    // Setters
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }
    public void setCost(double cost) { this.cost = cost; }
    public void setDescription(String description) { this.description = description; }
    
    @Override
    public String toString() {
        return serviceName + " - $" + cost + " (" + description + ")";
    }
}

