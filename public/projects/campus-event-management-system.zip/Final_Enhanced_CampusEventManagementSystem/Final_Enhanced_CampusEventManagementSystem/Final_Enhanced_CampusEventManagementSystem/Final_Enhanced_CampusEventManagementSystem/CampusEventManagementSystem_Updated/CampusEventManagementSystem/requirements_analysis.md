## Requirements Analysis: Campus Event Management System

### Functional Requirements:

1.  **Event Creation and Management:**
    *   Event organizers can create new events.
    *   Event organizers can update existing events.
    *   Event organizers can cancel events.
    *   Each event must include: event name, date, venue, type, capacity, and optional registration fee.
    *   Supported event types: Seminars, Workshops, Cultural Events, Sports Events.

2.  **Registration System:**
    *   Students and staff can register for events.
    *   For events with fees, the system must calculate:
        *   Base registration fee.
        *   Additional optional services (e.g., catering, transportation).
        *   Applicable discounts (e.g., early bird, group registration).

3.  **Fee Calculation and Display:**
    *   The application must display a detailed bill.
    *   Bill details: fee breakdown (base fee, additional services, discounts applied), total amount before discount, discount amount, net payable amount.

4.  **User Interface:**
    *   Attractive and user-friendly interface using Java Swing.
    *   Smooth navigation.
    *   Clear event details display.
    *   Responsive feedback to user actions.

### Non-Functional Requirements:

1.  **Future-Proof Design:**
    *   Easy incorporation of new event types, registration schemes, and discount strategies without major redesign.
    *   Incorporation of proper object-oriented principles for scalability and ease of maintenance.

2.  **Technology Stack:**
    *   Implementation should only use Java Swing Framework.

### Key Entities:

*   **Event:** Represents an event with attributes like name, date, venue, type, capacity, fee.
*   **Organizer:** User responsible for creating, updating, and canceling events.
*   **Participant:** Users (students/staff) who register for events.
*   **Registration:** Links a participant to an event, including selected services and applied discounts.
*   **Fee/Bill:** Represents the financial aspects of a registration, including breakdown and total amounts.
*   **Discount:** Represents different types of discounts (early bird, group).
*   **Optional Service:** Represents additional services like catering or transportation.





### UML Diagrams Generated:

*   **Use Case Diagram:** `/home/ubuntu/use_case_diagram.png`
*   **Class Diagram:** `/home/ubuntu/class_diagram.png`
*   **Sequence Diagram (Event Creation):** `/home/ubuntu/sequence_diagram_event_creation.png`
*   **Sequence Diagram (Registration):** `/home/ubuntu/sequence_diagram_registration.png`
*   **Sequence Diagram (Fee Calculation):** `/home/ubuntu/sequence_diagram_fee_calculation.png`


