# Campus Event Management System

## Overview
This is a comprehensive Java Swing-based application designed for managing campus events, registrations, and fee calculations. The system implements object-oriented design principles and incorporates the Builder design pattern for flexible registration creation.

## Features
- **Event Management**: Create, update, and delete various types of events (Seminars, Workshops, Cultural Events, Sports Events)
- **Registration System**: Allow participants to register for events with optional services
- **Fee Calculation**: Automatic calculation of fees including base costs, optional services, and applicable discounts
- **User-Friendly GUI**: Intuitive tabbed interface built with Java Swing
- **Extensible Design**: Built with future expansion in mind using proper OOP principles

## System Requirements
- Java Development Kit (JDK) 8 or higher
- Java Swing (included with JDK)

## Installation and Running
1. Navigate to the `src` directory
2. Compile all Java files: `javac *.java`
3. Run the application: `java CampusEventManagementGUI`

## Architecture
The system follows a layered architecture with clear separation of concerns:
- **Model Layer**: Event, User, Registration, and related classes
- **Business Logic Layer**: EventManager, RegistrationManager
- **Presentation Layer**: CampusEventManagementGUI (Swing-based)

## Design Patterns
- **Builder Pattern**: Used for Registration object creation to handle complex construction with optional services and discounts
- **Inheritance**: Event hierarchy (Seminar, Workshop, CulturalEvent, SportsEvent)
- **Polymorphism**: Abstract classes and method overriding for extensibility

## Key Classes
- `Event` (Abstract): Base class for all event types
- `Registration`: Complex object built using Builder pattern
- `EventManager`: Manages all events and available services/discounts
- `RegistrationManager`: Handles registration creation and management
- `CampusEventManagementGUI`: Main GUI application

## Usage
1. **Event Management Tab**: Create and manage different types of events
2. **Event Registration Tab**: Register participants for events with optional services
3. **View Registrations Tab**: View all completed registrations

## Testing
The application includes sample data for testing purposes and comprehensive error handling for user input validation.

