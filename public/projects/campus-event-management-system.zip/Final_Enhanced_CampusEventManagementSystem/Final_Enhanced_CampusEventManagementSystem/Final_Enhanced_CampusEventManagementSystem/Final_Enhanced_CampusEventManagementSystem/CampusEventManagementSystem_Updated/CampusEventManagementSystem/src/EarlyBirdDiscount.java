import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class EarlyBirdDiscount extends Discount {
    private double discountPercentage;
    private int daysBeforeEvent;
    
    public EarlyBirdDiscount(double discountPercentage, int daysBeforeEvent) {
        super("Early Bird Discount", "Discount for early registration");
        this.discountPercentage = discountPercentage;
        this.daysBeforeEvent = daysBeforeEvent;
    }
    
    public double getDiscountPercentage() { return discountPercentage; }
    public int getDaysBeforeEvent() { return daysBeforeEvent; }
    
    public void setDiscountPercentage(double discountPercentage) { this.discountPercentage = discountPercentage; }
    public void setDaysBeforeEvent(int daysBeforeEvent) { this.daysBeforeEvent = daysBeforeEvent; }
    
    @Override
    public double calculateDiscount(double totalAmount) {
        return totalAmount * (discountPercentage / 100.0);
    }
    
    @Override
    public boolean isApplicable(Registration registration) {
        LocalDate registrationDate = registration.getRegistrationDate();
        LocalDate eventDate = registration.getEvent().getDate();
        long daysBetween = ChronoUnit.DAYS.between(registrationDate, eventDate);
        return daysBetween >= daysBeforeEvent;
    }
    
    @Override
    public String toString() {
        return super.toString() + " (" + discountPercentage + "% if registered " + daysBeforeEvent + " days before event)";
    }
}

