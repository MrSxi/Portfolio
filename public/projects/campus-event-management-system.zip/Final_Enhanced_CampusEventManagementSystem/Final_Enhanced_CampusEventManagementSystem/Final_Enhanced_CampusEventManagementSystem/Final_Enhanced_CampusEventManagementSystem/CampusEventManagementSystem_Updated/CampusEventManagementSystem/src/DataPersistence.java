import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DataPersistence {
    private static final String DATA_FILE = "events_data.ser";
    private static final String REGISTRATIONS_FILE = "registrations_data.ser";
    
    // Save events to file
    public static void saveEvents(List<Event> events) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(events);
        } catch (IOException e) {
            System.err.println("Error saving events: " + e.getMessage());
        }
    }
    
    // Load events from file
    @SuppressWarnings("unchecked")
    public static List<Event> loadEvents() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            return (List<Event>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No existing events data found or error loading: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    
    // Save registrations to file
    public static void saveRegistrations(List<Registration> registrations) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(REGISTRATIONS_FILE))) {
            oos.writeObject(registrations);
        } catch (IOException e) {
            System.err.println("Error saving registrations: " + e.getMessage());
        }
    }
    
    // Load registrations from file
    @SuppressWarnings("unchecked")
    public static List<Registration> loadRegistrations() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(REGISTRATIONS_FILE))) {
            return (List<Registration>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No existing registrations data found or error loading: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}

