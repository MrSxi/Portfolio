public class StaffDiscount extends Discount {
    
    public StaffDiscount() {
        super("Staff Registration Discount", "Free registration for all staff members");
    }
    
    @Override
    public double calculateDiscount(double totalAmount) {
        // Return the full amount as discount (making it free)
        return totalAmount;
    }
    
    @Override
    public boolean isApplicable(Registration registration) {
        // Check if the primary participant is staff
        Participant primaryParticipant = registration.getParticipant();
        if (primaryParticipant != null && "Staff".equals(primaryParticipant.getParticipantType())) {
            return true;
        }
        
        // Also check all participants in the group
        if (registration.getAllParticipants() != null) {
            for (Participant p : registration.getAllParticipants()) {
                if (p != null && "Staff".equals(p.getParticipantType())) {
                    return true; // If any participant is staff, apply staff discount
                }
            }
        }
        
        return false;
    }
    
    @Override
    public String toString() {
        return super.toString() + " (100% discount for staff registrations)";
    }
}
