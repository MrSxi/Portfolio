public class Participant extends User {
    private String studentId;
    private String participantType; // "Student" or "Staff"
    
    public Participant(String userId, String name, String email, String studentId, String participantType) {
        super(userId, name, email);
        this.studentId = studentId;
        this.participantType = participantType;
    }
    
    public String getStudentId() { return studentId; }
    public String getParticipantType() { return participantType; }
    
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public void setParticipantType(String participantType) { this.participantType = participantType; }
    
    @Override
    public String getUserType() {
        return "Participant (" + participantType + ")";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - ID: " + studentId;
    }
}

