import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

public class StudentStaffPortalGUI extends JFrame {
    private EventManager eventManager;
    private RegistrationManager registrationManager;
    private String currentUser;
    
    // Registration Components
    private JComboBox<Event> eventCombo;
    private List<JTextField> participantNameFields;
    private List<JTextField> participantEmailFields;
    private List<JTextField> participantIdFields;
    private JComboBox<String> participantTypeCombo;
    private JList<OptionalService> servicesList;
    private JTextField groupSizeField;
    private JTextArea billArea;
    private JPanel participantDetailsPanel;
    
    public StudentStaffPortalGUI(String username) {
        this.currentUser = username;
        
        eventManager = new EventManager();
        registrationManager = new RegistrationManager(eventManager);
        
        initializeGUI();
        
        if (eventManager.getAllEvents().isEmpty()) {
            loadSampleData();
        }
        
        refreshEventCombo();
        
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            eventManager.saveAllData();
            registrationManager.saveAllData();
        }));
    }
    
    private void initializeGUI() {
        setTitle("Campus Event Management System - Student & Staff Portal (" + currentUser + ")");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Add logout button
        JPanel topPanel = new JPanel(new BorderLayout());
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> logout());
        
        JPanel userInfoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        userInfoPanel.add(new JLabel("Logged in as: " + currentUser + " (Student & Staff Portal)"));
        userInfoPanel.add(logoutButton);
        
        topPanel.add(userInfoPanel, BorderLayout.EAST);
        
        // Create registration panel
        JPanel registrationPanel = createRegistrationPanel();
        
        add(topPanel, BorderLayout.NORTH);
        add(registrationPanel, BorderLayout.CENTER);
    }
    
    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Logout Confirmation", 
            JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                new LoginGUI().setVisible(true);
            });
        }
    }
    
    private JPanel createRegistrationPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Registration form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Event Registration"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Event selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Event:"), gbc);
        gbc.gridx = 1;
        eventCombo = new JComboBox<>();
        formPanel.add(eventCombo, gbc);
        
        // Participant Type - Both students and staff can choose
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Participant Type:"), gbc);
        gbc.gridx = 1;
        participantTypeCombo = new JComboBox<>(new String[]{"Student", "Staff"});
        formPanel.add(participantTypeCombo, gbc);
        
        // Group size
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Group Size:"), gbc);
        gbc.gridx = 1;
        groupSizeField = new JTextField("1", 20);
        groupSizeField.addActionListener(e -> updateParticipantFields());
        formPanel.add(groupSizeField, gbc);
        
        JButton updateFieldsButton = new JButton("Update Fields");
        updateFieldsButton.addActionListener(e -> updateParticipantFields());
        gbc.gridx = 2;
        formPanel.add(updateFieldsButton, gbc);
        
        // Participant details panel (dynamic)
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        participantDetailsPanel = new JPanel();
        participantDetailsPanel.setBorder(BorderFactory.createTitledBorder("Participant Details"));
        JScrollPane participantScrollPane = new JScrollPane(participantDetailsPanel);
        participantScrollPane.setPreferredSize(new Dimension(600, 200));
        formPanel.add(participantScrollPane, gbc);
        
        // Initialize participant fields
        participantNameFields = new ArrayList<>();
        participantEmailFields = new ArrayList<>();
        participantIdFields = new ArrayList<>();
        updateParticipantFields();
        
        // Optional services
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Optional Services:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        servicesList = new JList<>();
        servicesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane servicesScrollPane = new JScrollPane(servicesList);
        servicesScrollPane.setPreferredSize(new Dimension(400, 100));
        formPanel.add(servicesScrollPane, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton registerButton = new JButton("Register");
        JButton calculateButton = new JButton("Calculate Fee");
        JButton clearButton = new JButton("Clear Form");
        
        registerButton.addActionListener(e -> registerParticipant());
        calculateButton.addActionListener(e -> calculateFee());
        clearButton.addActionListener(e -> clearRegistrationForm());
        
        buttonPanel.add(calculateButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(clearButton);
        
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 3;
        formPanel.add(buttonPanel, gbc);
        
        // Bill display
        billArea = new JTextArea(15, 50);
        billArea.setEditable(false);
        billArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane billScrollPane = new JScrollPane(billArea);
        billScrollPane.setBorder(BorderFactory.createTitledBorder("Registration Bill"));
        
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(billScrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void updateParticipantFields() {
        try {
            int groupSize = Integer.parseInt(groupSizeField.getText().trim());
            if (groupSize < 1) {
                JOptionPane.showMessageDialog(this, "Group size must be at least 1.", "Error", JOptionPane.ERROR_MESSAGE);
                groupSizeField.setText("1");
                return;
            }
            
            // Clear existing fields
            participantNameFields.clear();
            participantEmailFields.clear();
            participantIdFields.clear();
            participantDetailsPanel.removeAll();
            
            // Create new layout
            participantDetailsPanel.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.anchor = GridBagConstraints.WEST;
            
            // Add headers
            gbc.gridx = 0; gbc.gridy = 0;
            participantDetailsPanel.add(new JLabel("Participant"), gbc);
            gbc.gridx = 1;
            participantDetailsPanel.add(new JLabel("Name"), gbc);
            gbc.gridx = 2;
            participantDetailsPanel.add(new JLabel("Email"), gbc);
            gbc.gridx = 3;
            participantDetailsPanel.add(new JLabel("ID"), gbc);
            
            // Create fields for each participant
            for (int i = 0; i < groupSize; i++) {
                gbc.gridy = i + 1;
                
                // Participant number
                gbc.gridx = 0;
                participantDetailsPanel.add(new JLabel("Person " + (i + 1) + ":"), gbc);
                
                // Name field
                gbc.gridx = 1;
                JTextField nameField = new JTextField(15);
                participantNameFields.add(nameField);
                participantDetailsPanel.add(nameField, gbc);
                
                // Email field
                gbc.gridx = 2;
                JTextField emailField = new JTextField(20);
                participantEmailFields.add(emailField);
                participantDetailsPanel.add(emailField, gbc);
                
                // ID field
                gbc.gridx = 3;
                JTextField idField = new JTextField(10);
                participantIdFields.add(idField);
                participantDetailsPanel.add(idField, gbc);
            }
            
            participantDetailsPanel.revalidate();
            participantDetailsPanel.repaint();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for group size.", "Error", JOptionPane.ERROR_MESSAGE);
            groupSizeField.setText("1");
        }
    }
    
    private void refreshEventCombo() {
        eventCombo.removeAllItems();
        for (Event event : eventManager.getAvailableEvents()) {
            eventCombo.addItem(event);
        }
        
        // Update services list
        DefaultListModel<OptionalService> listModel = new DefaultListModel<>();
        for (OptionalService service : eventManager.getAvailableServices()) {
            listModel.addElement(service);
        }
        servicesList.setModel(listModel);
    }
    
    private void registerParticipant() {
        try {
            Event selectedEvent = (Event) eventCombo.getSelectedItem();
            if (selectedEvent == null) {
                JOptionPane.showMessageDialog(this, "Please select an event.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int groupSize = Integer.parseInt(groupSizeField.getText().trim());
            String participantType = (String) participantTypeCombo.getSelectedItem();
            
            // Check capacity FIRST before creating participants
            if (selectedEvent.getAvailableSpots() < groupSize) {
                JOptionPane.showMessageDialog(this, 
                    "Not enough spots available. Available spots: " + selectedEvent.getAvailableSpots() + 
                    ", Requested: " + groupSize, "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Validate all participant details and create participant objects
            List<Participant> allParticipants = new ArrayList<>();
            
            for (int i = 0; i < groupSize; i++) {
                String name = participantNameFields.get(i).getText().trim();
                String email = participantEmailFields.get(i).getText().trim();
                String id = participantIdFields.get(i).getText().trim();
                
                if (name.isEmpty() || email.isEmpty() || id.isEmpty()) {
                    JOptionPane.showMessageDialog(this, 
                        "Please fill in all details for participant " + (i + 1) + ".", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (!email.contains("@")) {
                    JOptionPane.showMessageDialog(this, 
                        "Please enter a valid email address for participant " + (i + 1) + ".", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Create participant object
                Participant participant = new Participant(id, name, email, id, participantType);
                allParticipants.add(participant);
            }
            
            // Create registration with all participants
            List<OptionalService> selectedServices = servicesList.getSelectedValuesList();
            Registration registration = registrationManager.createRegistration(
                allParticipants.get(0), selectedEvent, selectedServices, groupSize, allParticipants);
            
            billArea.setText(registration.getBillDetails());
            
            // Refresh event combo
            refreshEventCombo();
            
            // Show success message with appropriate text for staff vs student
            String successMessage = "Registration completed successfully!\n" +
                                   "Group size: " + groupSize + " participants\n";
            
            if ("Staff".equals(participantType)) {
                successMessage += "Total amount: FREE (Staff Registration)\n" +
                                "*** NO PAYMENT REQUIRED ***";
            } else {
                successMessage += "Total amount: $" + String.format("%.2f", registration.getNetAmount());
            }
            
            JOptionPane.showMessageDialog(this, successMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
            clearRegistrationForm();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid group size.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error during registration: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // For debugging
        }
    }
    
    private void calculateFee() {
        try {             Event selectedEvent = (Event) eventCombo.getSelectedItem();
            if (selectedEvent == null) {
                JOptionPane.showMessageDialog(this, "Please select an event.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int groupSize = Integer.parseInt(groupSizeField.getText().trim());
            String participantType = (String) participantTypeCombo.getSelectedItem();
            
            // Validate at least the first participant
            if (participantNameFields.isEmpty() || participantNameFields.get(0).getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in at least the first participant's details.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String name = participantNameFields.get(0).getText().trim();
            String email = participantEmailFields.get(0).getText().trim();
            String id = participantIdFields.get(0).getText().trim();
            
            if (name.isEmpty() || email.isEmpty() || id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in the first participant's details.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!email.contains("@")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Participant tempParticipant = new Participant(id, name, email, id, participantType);
            List<OptionalService> selectedServices = servicesList.getSelectedValuesList();
            
            String tempId = "TEMP-CALC";
            Registration.RegistrationBuilder builder = new Registration.RegistrationBuilder(tempId, tempParticipant, selectedEvent);
            
            for (OptionalService service : selectedServices) {
                builder.addOptionalService(service);
            }
            
            builder.setGroupSize(groupSize);
            
            for (Discount discount : eventManager.getAvailableDiscounts()) {
                builder.addDiscount(discount);
            }
            
            Registration tempRegistration = builder.build();
            billArea.setText(tempRegistration.getBillDetails());
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid group size.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error calculating fee: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearRegistrationForm() {
        // Clear all participant fields
        for (JTextField field : participantNameFields) {
            field.setText("");
        }
        for (JTextField field : participantEmailFields) {
            field.setText("");
        }
        for (JTextField field : participantIdFields) {
            field.setText("");
        }
        
        groupSizeField.setText("1");
        servicesList.clearSelection();
        billArea.setText("");
        participantTypeCombo.setSelectedIndex(0); // Default to "Student"
        
        // Reset to single participant
        updateParticipantFields();
    }
    
    private void loadSampleData() {
        // Same sample data as before
        LocalDate futureDate1 = LocalDate.now().plusDays(30);
        LocalDate futureDate2 = LocalDate.now().plusDays(45);
        LocalDate futureDate3 = LocalDate.now().plusDays(60);
        
        eventManager.addEvent(new Seminar("Java Programming Seminar", futureDate1, "Room A101", 50, 25.0, "Dr. Smith", "Advanced Java Concepts"));
        eventManager.addEvent(new Workshop("Web Development Workshop", futureDate2, "Lab B201", 30, 50.0, "Prof. Johnson", "Laptop required"));
        eventManager.addEvent(new CulturalEvent("Cultural Night", futureDate3, "Main Auditorium", 200, 15.0, "Music & Dance", "Student Performers"));
    }
}

            