import java.time.LocalDate;

public class CulturalEvent extends Event {
    private String culturalType;
    private String performers;
    
    public CulturalEvent(String name, LocalDate date, String venue, int capacity, double baseFee, String culturalType, String performers) {
        super(name, date, venue, capacity, baseFee);
        this.culturalType = culturalType;
        this.performers = performers;
    }
    
    public String getCulturalType() { return culturalType; }
    public String getPerformers() { return performers; }
    
    public void setCulturalType(String culturalType) { this.culturalType = culturalType; }
    public void setPerformers(String performers) { this.performers = performers; }
    
    @Override
    public String getEventType() {
        return "Cultural Event";
    }
    
    @Override
    public String toString() {
        return super.toString() + " - Type: " + culturalType + ", Performers: " + performers;
    }
}

