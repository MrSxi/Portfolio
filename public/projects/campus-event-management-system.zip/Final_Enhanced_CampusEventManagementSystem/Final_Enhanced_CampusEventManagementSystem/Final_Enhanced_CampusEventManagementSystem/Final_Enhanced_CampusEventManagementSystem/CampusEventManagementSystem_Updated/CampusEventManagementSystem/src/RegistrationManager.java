import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RegistrationManager {
    private List<Registration> registrations;
    private EventManager eventManager;
    
    public RegistrationManager(EventManager eventManager) {
    this.eventManager = eventManager;
    this.registrations = new ArrayList<>();
    
    // Load existing registrations
    loadData();
    
    // IMPORTANT: Sync registrations with events after loading
    eventManager.syncRegistrationsWithEvents(registrations);
}

    public Registration createRegistration(Participant primaryParticipant, Event event, 
                                         List<OptionalService> selectedServices, int groupSize) {
        return createRegistration(primaryParticipant, event, selectedServices, groupSize, new ArrayList<>());
    }
    
    public Registration createRegistration(Participant participant, Event event, 
                                     List<OptionalService> services, int groupSize, 
                                     List<Participant> allParticipants) {
    String registrationId = generateRegistrationId();
    
    Registration.RegistrationBuilder builder = new Registration.RegistrationBuilder(registrationId, participant, event);
    
    // Set all participants
    if (allParticipants != null && !allParticipants.isEmpty()) {
        builder.setAllParticipants(allParticipants);
    }
    
    // Add services
    for (OptionalService service : services) {
        builder.addOptionalService(service);
    }
    
    // Set group size
    builder.setGroupSize(groupSize);
    
    // Add available discounts
    for (Discount discount : eventManager.getAvailableDiscounts()) {
        builder.addDiscount(discount);
    }
    
    Registration registration = builder.build();
    
    // CRITICAL: Add registration to both lists
    registrations.add(registration);
    event.addRegistration(registration); // This updates the event's participant count
    
    // Save both registrations and events data
    saveAllData();
    eventManager.saveAllData(); // Make sure event data is also saved
    
    return registration;
}

    
    public List<Registration> getAllRegistrations() {
        return new ArrayList<>(registrations);
    }
    
    public List<Registration> getRegistrationsByEvent(Event event) {
        return registrations.stream()
                .filter(reg -> reg.getEvent().equals(event))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    public Registration getRegistrationById(String registrationId) {
        return registrations.stream()
                .filter(reg -> reg.getRegistrationId().equals(registrationId))
                .findFirst()
                .orElse(null);
    }
    
    private String generateRegistrationId() {
        return "REG-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
    
    private void loadData() {
        this.registrations = DataPersistence.loadRegistrations();
    }
    
    private void saveData() {
        DataPersistence.saveRegistrations(registrations);
    }
    
    public void saveAllData() {
        saveData();
    }
}
