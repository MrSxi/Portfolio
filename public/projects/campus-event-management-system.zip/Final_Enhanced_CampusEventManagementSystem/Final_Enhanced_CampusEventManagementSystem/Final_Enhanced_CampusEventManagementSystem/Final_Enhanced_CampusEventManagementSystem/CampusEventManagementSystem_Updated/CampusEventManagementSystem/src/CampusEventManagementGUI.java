import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class CampusEventManagementGUI extends JFrame {
    private EventManager eventManager;
    private RegistrationManager registrationManager;
    private JTabbedPane tabbedPane;
    private boolean isStaff;
    private String currentUser;
    
    // Event Management Components
    private JTable eventTable;
    private DefaultTableModel eventTableModel;
    private JTextField eventNameField, eventVenueField, eventCapacityField, eventFeeField, eventDateField;
    private JComboBox<String> eventTypeCombo;
    private JTextField specificField1, specificField2;
    private JLabel specificLabel1, specificLabel2;
    
    // Registration Components
    private JComboBox<Event> eventCombo;
    private List<JTextField> participantNameFields;
    private List<JTextField> participantEmailFields;
    private List<JTextField> participantIdFields;
    private JComboBox<String> participantTypeCombo;
    private JList<OptionalService> servicesList;
    private JTextField groupSizeField;
    private JTextArea billArea;
    private JPanel participantDetailsPanel;
    
    // View Registrations Components
    private JTable registrationTable;
    private DefaultTableModel registrationTableModel;
    
    public CampusEventManagementGUI(boolean isStaff, String username) {
    this.isStaff = isStaff;  // This determines admin privileges
    this.currentUser = username;
    
    eventManager = new EventManager();
    registrationManager = new RegistrationManager(eventManager);
    
    initializeGUI();
    
    if (eventManager.getAllEvents().isEmpty()) {
        loadSampleData();
    }
    
    refreshEventTable();
    refreshEventCombo();
    
    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        eventManager.saveAllData();
        registrationManager.saveAllData();
    }));
}

private void initializeGUI() {
    String userTypeDisplay = isStaff ? "Admin Portal" : "Student & Staff Portal";
    setTitle("Campus Event Management System - " + userTypeDisplay + " (" + currentUser + ")");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1200, 800);
    setLocationRelativeTo(null);
    
    tabbedPane = new JTabbedPane();
    
    // Add logout button
    JPanel topPanel = new JPanel(new BorderLayout());
    JButton logoutButton = new JButton("Logout");
    logoutButton.addActionListener(e -> logout());
    
    JPanel userInfoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    userInfoPanel.add(new JLabel("Logged in as: " + currentUser + " (" + userTypeDisplay + ")"));
    userInfoPanel.add(logoutButton);
    
    topPanel.add(userInfoPanel, BorderLayout.EAST);
    
    // Create tabs based on user role - THIS IS THE KEY PART
    if (isStaff) {
        // Admin Portal - Full access to all tabs
        tabbedPane.addTab("Event Management", createEventManagementPanel());
        tabbedPane.addTab("Event Registration", createRegistrationPanel());
        tabbedPane.addTab("View Registrations", createViewRegistrationsPanel());
    } else {
        // Student & Staff Portal - Registration only
        tabbedPane.addTab("Event Registration", createRegistrationPanel());
        // NO other tabs for regular users
    }
    
    add(topPanel, BorderLayout.NORTH);
    add(tabbedPane, BorderLayout.CENTER);
}



    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Logout Confirmation", 
            JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                new LoginGUI().setVisible(true);
            });
        }
    }
    
    private JPanel createEventManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Event form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Create/Edit Event"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Event Name
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Event Name:"), gbc);
        gbc.gridx = 1;
        eventNameField = new JTextField(20);
        formPanel.add(eventNameField, gbc);
        
        // Event Date
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        eventDateField = new JTextField(20);
        formPanel.add(eventDateField, gbc);
        
        // Event Venue
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Venue:"), gbc);
        gbc.gridx = 1;
        eventVenueField = new JTextField(20);
        formPanel.add(eventVenueField, gbc);
        
        // Event Capacity
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1;
        eventCapacityField = new JTextField(20);
        formPanel.add(eventCapacityField, gbc);
        
        // Event Fee
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("Base Fee:"), gbc);
        gbc.gridx = 1;
        eventFeeField = new JTextField(20);
        formPanel.add(eventFeeField, gbc);
        
        // Event Type
        gbc.gridx = 0; gbc.gridy = 5;
        formPanel.add(new JLabel("Event Type:"), gbc);
        gbc.gridx = 1;
        eventTypeCombo = new JComboBox<>(new String[]{"Seminar", "Workshop", "Cultural Event", "Sports Event"});
        eventTypeCombo.addActionListener(e -> updateSpecificFields());
        formPanel.add(eventTypeCombo, gbc);
        
        // Specific fields
        gbc.gridx = 0; gbc.gridy = 6;
        specificLabel1 = new JLabel();
        formPanel.add(specificLabel1, gbc);
        gbc.gridx = 1;
        specificField1 = new JTextField(20);
        formPanel.add(specificField1, gbc);
        
        gbc.gridx = 0; gbc.gridy = 7;
        specificLabel2 = new JLabel();
        formPanel.add(specificLabel2, gbc);
        gbc.gridx = 1;
        specificField2 = new JTextField(20);
        formPanel.add(specificField2, gbc);
        
        updateSpecificFields();
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton createButton = new JButton("Create Event");
        JButton updateButton = new JButton("Update Event");
        JButton deleteButton = new JButton("Delete Event");
        JButton clearButton = new JButton("Clear Form");
        
        createButton.addActionListener(e -> createEvent());
        updateButton.addActionListener(e -> updateEvent());
        deleteButton.addActionListener(e -> deleteEvent());
        clearButton.addActionListener(e -> clearEventForm());
        
        buttonPanel.add(createButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        
        gbc.gridx = 0; gbc.gridy = 8;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);
        
        // Event table
        String[] columnNames = {"Name", "Date", "Venue", "Type", "Capacity", "Registered", "Fee"};
        eventTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        eventTable = new JTable(eventTableModel);
        eventTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        eventTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedEvent();
            }
        });
        
        JScrollPane tableScrollPane = new JScrollPane(eventTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("Events"));
        
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(tableScrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void updateSpecificFields() {
        String selectedType = (String) eventTypeCombo.getSelectedItem();
        switch (selectedType) {
            case "Seminar":
                specificLabel1.setText("Speaker:");
                specificLabel2.setText("Topic:");
                break;
            case "Workshop":
                specificLabel1.setText("Instructor:");
                specificLabel2.setText("Materials:");
                break;
            case "Cultural Event":
                specificLabel1.setText("Cultural Type:");
                specificLabel2.setText("Performers:");
                break;
            case "Sports Event":
                specificLabel1.setText("Sport Type:");
                specificLabel2.setText("Equipment:");
                break;
        }
    }
    
   private JPanel createRegistrationPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBorder(new EmptyBorder(10, 10, 10, 10));
    
    // Registration form
    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBorder(BorderFactory.createTitledBorder("Event Registration"));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.anchor = GridBagConstraints.WEST;
    
    // Event selection
    gbc.gridx = 0; gbc.gridy = 0;
    formPanel.add(new JLabel("Select Event:"), gbc);
    gbc.gridx = 1;
    eventCombo = new JComboBox<>();
    formPanel.add(eventCombo, gbc);
    
    // Participant Type - ALWAYS ENABLED for both admin and student/staff portal
    gbc.gridx = 0; gbc.gridy = 1;
    formPanel.add(new JLabel("Participant Type:"), gbc);
    gbc.gridx = 1;
    participantTypeCombo = new JComboBox<>(new String[]{"Student", "Staff"});
    participantTypeCombo.setEnabled(true); // Explicitly enable it
    
    // Add action listener to show different messages based on selection
    participantTypeCombo.addActionListener(e -> {
        String selectedType = (String) participantTypeCombo.getSelectedItem();
        if ("Staff".equals(selectedType)) {
            participantTypeCombo.setToolTipText("Staff registrations are FREE");
        } else {
            participantTypeCombo.setToolTipText("Student registration with applicable fees");
        }
    });
    
    formPanel.add(participantTypeCombo, gbc);
    
    // Group size with discount message
    gbc.gridx = 0; gbc.gridy = 2;
    formPanel.add(new JLabel("Group Size:"), gbc);
    gbc.gridx = 1;
    groupSizeField = new JTextField("1", 15); // Made slightly smaller to fit the message
    groupSizeField.addActionListener(e -> updateParticipantFields());
    formPanel.add(groupSizeField, gbc);
    
    // Add discount message next to group size - UPDATED TO 3+ PEOPLE
    gbc.gridx = 2;
    JLabel discountMessageLabel = new JLabel("💡 3+ people get 15% group discount!");
    discountMessageLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 11));
    discountMessageLabel.setForeground(new java.awt.Color(0, 128, 0)); // Green color
    formPanel.add(discountMessageLabel, gbc);
    
    // Update Fields button (moved to next row)
    gbc.gridx = 1; gbc.gridy = 3;
    JButton updateFieldsButton = new JButton("Update Fields");
    updateFieldsButton.addActionListener(e -> updateParticipantFields());
    formPanel.add(updateFieldsButton, gbc);
    
    // Additional discount information panel - UPDATED TO 3+ PEOPLE
    gbc.gridx = 0; gbc.gridy = 4;
    gbc.gridwidth = 3;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    JPanel discountInfoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    discountInfoPanel.setBorder(BorderFactory.createTitledBorder("💰 Available Discounts"));
    discountInfoPanel.setBackground(new java.awt.Color(240, 248, 255)); // Light blue background
    
    JLabel discountInfo = new JLabel("<html>" +
        "<b>🎯 Early Bird:</b> 10% off if registered 7+ days before event<br>" +
        "<b>👥 Group Discount:</b> 15% off for groups of 3 or more<br>" +
        "<b>🏢 Staff Discount:</b> FREE registration for all staff members" +
        "</html>");
    discountInfo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
    discountInfoPanel.add(discountInfo);
    
    formPanel.add(discountInfoPanel, gbc);
    
    // Participant details panel (dynamic)
    gbc.gridx = 0; gbc.gridy = 5;
    gbc.gridwidth = 3;
    gbc.fill = GridBagConstraints.BOTH;
    participantDetailsPanel = new JPanel();
    participantDetailsPanel.setBorder(BorderFactory.createTitledBorder("Participant Details"));
    JScrollPane participantScrollPane = new JScrollPane(participantDetailsPanel);
    participantScrollPane.setPreferredSize(new Dimension(600, 200));
    formPanel.add(participantScrollPane, gbc);
    
    // Initialize participant fields
    participantNameFields = new ArrayList<>();
    participantEmailFields = new ArrayList<>();
    participantIdFields = new ArrayList<>();
    updateParticipantFields();
    
    // Optional services
    gbc.gridx = 0; gbc.gridy = 6;
    gbc.gridwidth = 1;
    gbc.fill = GridBagConstraints.NONE;
    formPanel.add(new JLabel("Optional Services:"), gbc);
    gbc.gridx = 1;
    gbc.gridwidth = 2;
    servicesList = new JList<>();
    servicesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    JScrollPane servicesScrollPane = new JScrollPane(servicesList);
    servicesScrollPane.setPreferredSize(new Dimension(400, 100));
    formPanel.add(servicesScrollPane, gbc);
    
    // Buttons
    JPanel buttonPanel = new JPanel(new FlowLayout());
    JButton registerButton = new JButton("Register");
    JButton calculateButton = new JButton("Calculate Fee");
    JButton clearButton = new JButton("Clear Form");
    
    registerButton.addActionListener(e -> registerParticipant());
    calculateButton.addActionListener(e -> calculateFee());
    clearButton.addActionListener(e -> clearRegistrationForm());
    
    buttonPanel.add(calculateButton);
    buttonPanel.add(registerButton);
    buttonPanel.add(clearButton);
    
    gbc.gridx = 0; gbc.gridy = 7;
    gbc.gridwidth = 3;
    formPanel.add(buttonPanel, gbc);
    
    // Bill display
    billArea = new JTextArea(15, 50);
    billArea.setEditable(false);
    billArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
    JScrollPane billScrollPane = new JScrollPane(billArea);
    billScrollPane.setBorder(BorderFactory.createTitledBorder("Registration Bill"));
    
    panel.add(formPanel, BorderLayout.NORTH);
    panel.add(billScrollPane, BorderLayout.CENTER);
    
    return panel;
}

    
    private void updateParticipantFields() {
    try {
        int groupSize = Integer.parseInt(groupSizeField.getText().trim());
        if (groupSize < 1) {
            JOptionPane.showMessageDialog(this, "Group size must be at least 1.", "Error", JOptionPane.ERROR_MESSAGE);
            groupSizeField.setText("1");
            return;
        }
        
        // Show discount eligibility message - UPDATED TO 3+ PEOPLE
        if (groupSize >= 3) {
            groupSizeField.setToolTipText("✅ Group of " + groupSize + " qualifies for 15% group discount!");
            groupSizeField.setBackground(new java.awt.Color(240, 255, 240)); // Light green
        } else {
            groupSizeField.setToolTipText("Need " + (3 - groupSize) + " more people for 15% group discount");
            groupSizeField.setBackground(java.awt.Color.WHITE); // Normal white
        }
        
        // Clear existing fields
        participantNameFields.clear();
        participantEmailFields.clear();
        participantIdFields.clear();
        participantDetailsPanel.removeAll();
        
        // Create new layout
        participantDetailsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Add headers
        gbc.gridx = 0; gbc.gridy = 0;
        participantDetailsPanel.add(new JLabel("Participant"), gbc);
        gbc.gridx = 1;
        participantDetailsPanel.add(new JLabel("Name"), gbc);
        gbc.gridx = 2;
        participantDetailsPanel.add(new JLabel("Email"), gbc);
        gbc.gridx = 3;
        participantDetailsPanel.add(new JLabel("ID"), gbc);
        
        // Create fields for each participant
        for (int i = 0; i < groupSize; i++) {
            gbc.gridy = i + 1;
            
            // Participant number
            gbc.gridx = 0;
            String participantLabel = "Person " + (i + 1) + ":";
            if (i == 0) {
                participantLabel += " (Primary)";
            }
            participantDetailsPanel.add(new JLabel(participantLabel), gbc);
            
            // Name field
            gbc.gridx = 1;
            JTextField nameField = new JTextField(15);
            participantNameFields.add(nameField);
            participantDetailsPanel.add(nameField, gbc);
            
            // Email field
            gbc.gridx = 2;
            JTextField emailField = new JTextField(20);
            participantEmailFields.add(emailField);
            participantDetailsPanel.add(emailField, gbc);
            
            // ID field
            gbc.gridx = 3;
            JTextField idField = new JTextField(10);
            participantIdFields.add(idField);
            participantDetailsPanel.add(idField, gbc);
        }
        
        participantDetailsPanel.revalidate();
        participantDetailsPanel.repaint();
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid number for group size.", "Error", JOptionPane.ERROR_MESSAGE);
        groupSizeField.setText("1");
    }
}

    
    private JPanel createViewRegistrationsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Updated column names to show more participant details
        String[] columnNames = {"Registration ID", "Event", "Date", "Group Size", "All Participants", "Services", "Net Amount"};
        registrationTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable registrationTable = new JTable(registrationTableModel);
        
        // Set column widths for better display
        registrationTable.getColumnModel().getColumn(0).setPreferredWidth(120); // Registration ID
        registrationTable.getColumnModel().getColumn(1).setPreferredWidth(150); // Event
        registrationTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Date
        registrationTable.getColumnModel().getColumn(3).setPreferredWidth(80);  // Group Size
        registrationTable.getColumnModel().getColumn(4).setPreferredWidth(300); // All Participants
        registrationTable.getColumnModel().getColumn(5).setPreferredWidth(150); // Services
        registrationTable.getColumnModel().getColumn(6).setPreferredWidth(100); // Net Amount
        
        // Enable text wrapping for the participants column
        registrationTable.setRowHeight(60); // Increase row height to show multiple lines
        
        // Add double-click listener to show full details
        registrationTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int selectedRow = registrationTable.getSelectedRow();
                    if (selectedRow != -1) {
                        String regIdShort = (String) registrationTableModel.getValueAt(selectedRow, 0);
                        String regIdPrefix = regIdShort.replace("...", "");
                        
                        for (Registration reg : registrationManager.getAllRegistrations()) {
                            if (reg.getRegistrationId().startsWith(regIdPrefix)) {

                                CampusEventManagementGUI.this.showRegistrationDetailsDialog(reg);
                                break;
                            }
                        }
                    }
                }

            }        });        
        JScrollPane scrollPane = new JScrollPane(registrationTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("All Registrations (Double-click for full details)"));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshRegistrationTable());
        
        JButton exportButton = new JButton("Export All");
        exportButton.addActionListener(e -> exportRegistrations());
        
        JButton viewDetailsButton = new JButton("View Selected Details");
        viewDetailsButton.addActionListener(e -> {
            int selectedRow = registrationTable.getSelectedRow();
            if (selectedRow != -1) {
                String regIdShort = (String) registrationTableModel.getValueAt(selectedRow, 0);
                String regIdPrefix = regIdShort.replace("...", "");
                
                for (Registration reg : registrationManager.getAllRegistrations()) {
                    if (reg.getRegistrationId().startsWith(regIdPrefix)) {
                        showRegistrationDetailsDialog(reg);
                        break;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a registration to view details.", "No Selection", JOptionPane.INFORMATION_MESSAGE);
            }
        });        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(refreshButton);
        buttonPanel.add(viewDetailsButton);
        buttonPanel.add(exportButton);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Initial load
        refreshRegistrationTable();
        
        return panel;
    }
    
    private void viewRegistrationDetails() {
        int selectedRow = registrationTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a registration to view details.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String registrationId = (String) registrationTableModel.getValueAt(selectedRow, 0);
        
        // Find the full registration
        Registration selectedRegistration = null;
        for (Registration reg : registrationManager.getAllRegistrations()) {
            if (reg.getRegistrationId().startsWith(registrationId.replace("...", ""))) {
                selectedRegistration = reg;
                break;
            }
        }
        
        if (selectedRegistration != null) {
            showRegistrationDetailsDialog(selectedRegistration);
        }
    }
    
    private void showRegistrationDetailsDialog(Registration registration) {
    RegistrationDetailsDialog.showDialog(this, registration);
}

   private void refreshRegistrationTable() {
    registrationTableModel.setRowCount(0);
    
    for (Registration reg : registrationManager.getAllRegistrations()) {
        try {
            String services = reg.getSelectedServices().stream()
                    .map(OptionalService::getServiceName)
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("None");
            
            // Create detailed participant information for ALL participants
            StringBuilder participantDetails = new StringBuilder();
            List<Participant> allParticipants = reg.getAllParticipants();
            
            if (allParticipants != null && !allParticipants.isEmpty()) {
                for (int i = 0; i < allParticipants.size(); i++) {
                    Participant p = allParticipants.get(i);
                    if (p != null) {
                        participantDetails.append((i + 1)).append(". ")
                                       .append(p.getName())
                                       .append(" (").append(p.getEmail())
                                       .append(", ID: ").append(p.getStudentId())
                                       .append(", ").append(p.getParticipantType()).append(")");
                        
                        if (i == 0) {
                            participantDetails.append(" [Primary]");
                        }
                        
                        if (i < allParticipants.size() - 1) {
                            participantDetails.append("\n");
                        }
                    }
                }
            } else if (reg.getParticipant() != null) {
                // Fallback for old format registrations
                Participant p = reg.getParticipant();
                participantDetails.append("1. ").append(p.getName())
                               .append(" (").append(p.getEmail())
                               .append(", ID: ").append(p.getStudentId())
                               .append(", ").append(p.getParticipantType()).append(") [Primary]");
            } else {
                participantDetails.append("Unknown Participant");
            }
            
            // Create HTML formatted text for better display in table
            String formattedParticipants = "<html>" + participantDetails.toString().replace("\n", "<br>") + "</html>";
            
            registrationTableModel.addRow(new Object[]{
                reg.getRegistrationId().substring(0, Math.min(8, reg.getRegistrationId().length())) + "...",
                reg.getEvent() != null ? reg.getEvent().getName() : "Unknown Event",
                reg.getRegistrationDate() != null ? reg.getRegistrationDate().toString() : "Unknown Date",
                reg.getGroupSize(),
                formattedParticipants,
                services,
                String.format("$%.2f", reg.getNetAmount())
            });
            
        } catch (Exception e) {
            System.err.println("Error processing registration: " + e.getMessage());
            registrationTableModel.addRow(new Object[]{
                "ERROR",
                "Data Error",
                "Unknown",
                0,
                "Error loading participant data",
                "None",
                "$0.00"
            });
        }
    }
}

    
    private void exportRegistrations() {
        StringBuilder export = new StringBuilder();
        export.append("CAMPUS EVENT MANAGEMENT SYSTEM - REGISTRATIONS REPORT\n");
        export.append("Generated on: ").append(LocalDate.now()).append("\n");
        export.append("=".repeat(60)).append("\n\n");
        
        for (Registration reg : registrationManager.getAllRegistrations()) {
            export.append("Registration ID: ").append(reg.getRegistrationId()).append("\n");
            export.append("Participant: ").append(reg.getParticipant().getName()).append("\n");
            export.append("Email: ").append(reg.getParticipant().getEmail()).append("\n");
            export.append("Event: ").append(reg.getEvent().getName()).append("\n");
            export.append("Event Date: ").append(reg.getEvent().getDate()).append("\n");
            export.append("Registration Date: ").append(reg.getRegistrationDate()).append("\n");
            export.append("Group Size: ").append(reg.getGroupSize()).append("\n");
            export.append("Net Amount: $").append(String.format("%.2f", reg.getNetAmount())).append("\n");
            export.append("-".repeat(40)).append("\n");
        }
        
        // Show in dialog
        JDialog exportDialog = new JDialog(this, "Export Registrations", true);
        exportDialog.setSize(700, 500);
        exportDialog.setLocationRelativeTo(this);
        
        JTextArea exportArea = new JTextArea(export.toString());
        exportArea.setEditable(false);
        exportArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        
        JScrollPane scrollPane = new JScrollPane(exportArea);
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> exportDialog.dispose());
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(closeButton);
        
        exportDialog.add(scrollPane, BorderLayout.CENTER);
        exportDialog.add(buttonPanel, BorderLayout.SOUTH);
        exportDialog.setVisible(true);
    }
    
    private void loadSampleData() {
        LocalDate futureDate1 = LocalDate.now().plusDays(30);
        LocalDate futureDate2 = LocalDate.now().plusDays(45);
        LocalDate futureDate3 = LocalDate.now().plusDays(60);
        
        eventManager.addEvent(new Seminar("Java Programming Seminar", futureDate1, "Room A101", 50, 25.0, "Dr. Smith", "Advanced Java Concepts"));
        eventManager.addEvent(new Workshop("Web Development Workshop", futureDate2, "Lab B201", 30, 50.0, "Prof. Johnson", "Laptop required"));
        eventManager.addEvent(new CulturalEvent("Cultural Night", futureDate3, "Main Auditorium", 200, 15.0, "Music & Dance", "Student Performers"));
    }
    
 private void refreshEventTable() {
    if (eventTableModel != null) {
        eventTableModel.setRowCount(0);
        for (Event event : eventManager.getAllEvents()) {
            // Debug logging
            System.out.println("DEBUG: Event " + event.getName() + 
                             " - Registrations count: " + event.getRegistrations().size() + 
                             " - Total participants: " + event.getTotalRegisteredParticipants());
            
            // Ensure participant count is accurate
            event.recalculateTotalParticipants();
            
            System.out.println("DEBUG: After recalculation - Total participants: " + event.getTotalRegisteredParticipants());
            
            eventTableModel.addRow(new Object[]{
                event.getName(),
                event.getDate(),
                event.getVenue(),
                event.getEventType(),
                event.getCapacity(),
                event.getTotalRegisteredParticipants(), // This should show the correct count
                String.format("$%.2f", event.getBaseFee())
            });
        }
    }
}


    
    private void refreshEventCombo() {
        eventCombo.removeAllItems();
        for (Event event : eventManager.getAvailableEvents()) {
            eventCombo.addItem(event);
        }
        
        // Update services list
        DefaultListModel<OptionalService> listModel = new DefaultListModel<>();
        for (OptionalService service : eventManager.getAvailableServices()) {
            listModel.addElement(service);
        }
        servicesList.setModel(listModel);
    }
    
    private void createEvent() {
        try {
            String name = eventNameField.getText().trim();
            String dateStr = eventDateField.getText().trim();
            String venue = eventVenueField.getText().trim();
            String capacityStr = eventCapacityField.getText().trim();
            String feeStr = eventFeeField.getText().trim();
            String type = (String) eventTypeCombo.getSelectedItem();
            String specific1 = specificField1.getText().trim();
            String specific2 = specificField2.getText().trim();
            
                       if (name.isEmpty() || dateStr.isEmpty() || venue.isEmpty() || capacityStr.isEmpty() || feeStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            int capacity = Integer.parseInt(capacityStr);
            double fee = Double.parseDouble(feeStr);
            
            Event event = null;
            switch (type) {
                case "Seminar":
                    event = new Seminar(name, date, venue, capacity, fee, specific1, specific2);
                    break;
                case "Workshop":
                    event = new Workshop(name, date, venue, capacity, fee, specific1, specific2);
                    break;
                case "Cultural Event":
                    event = new CulturalEvent(name, date, venue, capacity, fee, specific1, specific2);
                    break;
                case "Sports Event":
                    event = new SportsEvent(name, date, venue, capacity, fee, specific1, specific2);
                    break;
            }
            
            eventManager.addEvent(event);
            refreshEventTable();
            refreshEventCombo();
            clearEventForm();
            
            JOptionPane.showMessageDialog(this, "Event created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number format for capacity or fee.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error creating event: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateEvent() {
        int selectedRow = eventTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to update.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String eventName = (String) eventTableModel.getValueAt(selectedRow, 0);
            Event existingEvent = eventManager.getEventByName(eventName);
            
            if (existingEvent == null) {
                JOptionPane.showMessageDialog(this, "Event not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String name = eventNameField.getText().trim();
            String dateStr = eventDateField.getText().trim();
            String venue = eventVenueField.getText().trim();
            String capacityStr = eventCapacityField.getText().trim();
            String feeStr = eventFeeField.getText().trim();
            String type = (String) eventTypeCombo.getSelectedItem();
            String specific1 = specificField1.getText().trim();
            String specific2 = specificField2.getText().trim();
            
            if (name.isEmpty() || dateStr.isEmpty() || venue.isEmpty() || capacityStr.isEmpty() || feeStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            int capacity = Integer.parseInt(capacityStr);
            double fee = Double.parseDouble(feeStr);
            
            if (capacity < existingEvent.getRegistrations().size()) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot reduce capacity below current registrations (" + existingEvent.getRegistrations().size() + ").", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            existingEvent.setName(name);
            existingEvent.setDate(date);
            existingEvent.setVenue(venue);
            existingEvent.setCapacity(capacity);
            existingEvent.setBaseFee(fee);
            
            if (existingEvent instanceof Seminar && type.equals("Seminar")) {
                Seminar seminar = (Seminar) existingEvent;
                seminar.setSpeaker(specific1);
                seminar.setTopic(specific2);
            } else if (existingEvent instanceof Workshop && type.equals("Workshop")) {
                Workshop workshop = (Workshop) existingEvent;
                workshop.setInstructor(specific1);
                workshop.setMaterials(specific2);
            } else if (existingEvent instanceof CulturalEvent && type.equals("Cultural Event")) {
                CulturalEvent cultural = (CulturalEvent) existingEvent;
                cultural.setCulturalType(specific1);
                cultural.setPerformers(specific2);
            } else if (existingEvent instanceof SportsEvent && type.equals("Sports Event")) {
                SportsEvent sports = (SportsEvent) existingEvent;
                sports.setSportType(specific1);
                sports.setEquipment(specific2);
            } else {
                JOptionPane.showMessageDialog(this, "Cannot change event type. Please create a new event.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            refreshEventTable();
            refreshEventCombo();
            clearEventForm();
            
            JOptionPane.showMessageDialog(this, "Event updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number format for capacity or fee.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating event: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteEvent() {
        int selectedRow = eventTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String eventName = (String) eventTableModel.getValueAt(selectedRow, 0);
        Event event = eventManager.getEventByName(eventName);
        
        if (event != null && event.getRegistrations().isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to delete the event '" + eventName + "'?", 
                "Confirm Delete", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                eventManager.removeEvent(event);
                refreshEventTable();
                refreshEventCombo();
                clearEventForm();
                JOptionPane.showMessageDialog(this, "Event deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Cannot delete event with existing registrations.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadSelectedEvent() {
        int selectedRow = eventTable.getSelectedRow();
        if (selectedRow == -1) return;
        
        String eventName = (String) eventTableModel.getValueAt(selectedRow, 0);
        Event event = eventManager.getEventByName(eventName);
        
        if (event != null) {
            eventNameField.setText(event.getName());
            eventDateField.setText(event.getDate().toString());
            eventVenueField.setText(event.getVenue());
            eventCapacityField.setText(String.valueOf(event.getCapacity()));
            eventFeeField.setText(String.valueOf(event.getBaseFee()));
            eventTypeCombo.setSelectedItem(event.getEventType());
            
            if (event instanceof Seminar) {
                Seminar seminar = (Seminar) event;
                specificField1.setText(seminar.getSpeaker());
                specificField2.setText(seminar.getTopic());
            } else if (event instanceof Workshop) {
                Workshop workshop = (Workshop) event;
                specificField1.setText(workshop.getInstructor());
                specificField2.setText(workshop.getMaterials());
            } else if (event instanceof CulturalEvent) {
                CulturalEvent cultural = (CulturalEvent) event;
                specificField1.setText(cultural.getCulturalType());
                specificField2.setText(cultural.getPerformers());
            } else if (event instanceof SportsEvent) {
                SportsEvent sports = (SportsEvent) event;
                specificField1.setText(sports.getSportType());
                specificField2.setText(sports.getEquipment());
            }
        }
    }
    
    private void clearEventForm() {
        eventNameField.setText("");
        eventDateField.setText("");
        eventVenueField.setText("");
        eventCapacityField.setText("");
        eventFeeField.setText("");
        specificField1.setText("");
        specificField2.setText("");
        eventTypeCombo.setSelectedIndex(0);
    }
   private void registerParticipant() {
    try {
        Event selectedEvent = (Event) eventCombo.getSelectedItem();
        if (selectedEvent == null) {
            JOptionPane.showMessageDialog(this, "Please select an event.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int groupSize = Integer.parseInt(groupSizeField.getText().trim());
        String participantType = (String) participantTypeCombo.getSelectedItem();
        
        // Check capacity FIRST before creating participants
        if (!selectedEvent.canAccommodateGroup(groupSize)) {
            JOptionPane.showMessageDialog(this, 
                "Not enough spots available. Available spots: " + selectedEvent.getAvailableSpots() + 
                ", Requested: " + groupSize, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate all participant details and create participant objects
        List<Participant> allParticipants = new ArrayList<>();
        
        for (int i = 0; i < groupSize; i++) {
            String name = participantNameFields.get(i).getText().trim();
            String email = participantEmailFields.get(i).getText().trim();
            String id = participantIdFields.get(i).getText().trim();
            
            if (name.isEmpty() || email.isEmpty() || id.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill in all details for participant " + (i + 1) + ".", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!email.contains("@")) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid email address for participant " + (i + 1) + ".", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // ID can now be alphanumeric (letters and numbers allowed)
            
            // Create participant object
            Participant participant = new Participant(id, name, email, id, participantType);
            allParticipants.add(participant);
        }
        
        // Create registration with all participants
        List<OptionalService> selectedServices = servicesList.getSelectedValuesList();
        Registration registration = registrationManager.createRegistration(
            allParticipants.get(0), selectedEvent, selectedServices, groupSize, allParticipants);
        
        billArea.setText(registration.getBillDetails());
        
        // Refresh all tables
        refreshEventTable();
        refreshEventCombo();
        if (registrationTableModel != null) {
            refreshRegistrationTable();
        }
        
        // Show success message with appropriate text for staff vs student
        String successMessage = "Registration completed successfully!\n" +
                               "Group size: " + groupSize + " participants\n";
        
        if ("Staff".equals(participantType)) {
            successMessage += "Total amount: FREE (Staff Registration)\n" +
                            "*** NO PAYMENT REQUIRED ***";
        } else {
            successMessage += "Total amount: $" + String.format("%.2f", registration.getNetAmount());
        }
        
        JOptionPane.showMessageDialog(this, successMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
        clearRegistrationForm();
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Invalid group size.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error during registration: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(); // For debugging
    }
}



   private void calculateFee() {
    try {
        Event selectedEvent = (Event) eventCombo.getSelectedItem();
        if (selectedEvent == null) {
            JOptionPane.showMessageDialog(this, "Please select an event.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int groupSize = Integer.parseInt(groupSizeField.getText().trim());
        String participantType = (String) participantTypeCombo.getSelectedItem();
        
        // Validate at least the first participant
        if (participantNameFields.isEmpty() || participantNameFields.get(0).getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in at least the first participant's details.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Create all participants for calculation
        List<Participant> allParticipants = new ArrayList<>();
        
        for (int i = 0; i < Math.min(groupSize, participantNameFields.size()); i++) {
            String name = participantNameFields.get(i).getText().trim();
            String email = participantEmailFields.get(i).getText().trim();
            String id = participantIdFields.get(i).getText().trim();
            
            if (name.isEmpty() || email.isEmpty() || id.isEmpty()) {
                if (i == 0) {
                    JOptionPane.showMessageDialog(this, "Please fill in the first participant's details.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                // For calculation purposes, use dummy data for incomplete participants
                name = "Participant " + (i + 1);
                email = "participant" + (i + 1) + "@example.com";
                id = "ID" + (i + 1);
            }
            
            if (!email.contains("@")) {
                if (i == 0) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                email = "participant" + (i + 1) + "@example.com";
            }
            
            // REMOVED: ID numeric validation - now accepts letters and numbers
            // ID can be alphanumeric
            
            Participant participant = new Participant(id, name, email, id, participantType);
            allParticipants.add(participant);
        }
        
        List<OptionalService> selectedServices = servicesList.getSelectedValuesList();
        
        String tempId = "TEMP-CALC";
        Registration.RegistrationBuilder builder = new Registration.RegistrationBuilder(tempId, allParticipants.get(0), selectedEvent);
        
        // Set all participants
        builder.setAllParticipants(allParticipants);
        
        for (OptionalService service : selectedServices) {
            builder.addOptionalService(service);
        }
        
        builder.setGroupSize(groupSize);
        
        for (Discount discount : eventManager.getAvailableDiscounts()) {
            builder.addDiscount(discount);
        }
        
        Registration tempRegistration = builder.build();
        billArea.setText(tempRegistration.getBillDetails());
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Invalid group size.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error calculating fee: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    
     private void clearRegistrationForm() {
    // Clear all participant fields
    for (JTextField field : participantNameFields) {
        field.setText("");
    }
    for (JTextField field : participantEmailFields) {
        field.setText("");
    }
    for (JTextField field : participantIdFields) {
        field.setText("");
    }
    
    groupSizeField.setText("1");
    servicesList.clearSelection();
    billArea.setText("");
    
    // Reset participant type to Student but keep it enabled
    participantTypeCombo.setSelectedIndex(0); // Default to "Student"
    participantTypeCombo.setEnabled(true); // Make sure it stays enabled
    
    // Reset to single participant
    updateParticipantFields();
}


    
  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        try {
            // Set Look and Feel to system default
            // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Start with login screen
        new LoginGUI().setVisible(true);
    });
}
}



